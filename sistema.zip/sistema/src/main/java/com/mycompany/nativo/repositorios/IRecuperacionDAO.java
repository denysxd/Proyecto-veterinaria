package com.mycompany.nativo.repositorios;

public interface IRecuperacionDAO {
    void guardarToken(int usuarioId, String token) throws Exception;
    int validarToken(String token) throws Exception; // Retorna ID de usuario si es válido, o 0
    void eliminarToken(String token) throws Exception;
}