package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.Almacen;
import com.mycompany.nativo.modelos.Producto; 
import com.mycompany.nativo.modelos.Usuarios;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlmacenDAOJDBC implements IAlmacenDAO {

  
    private static final String SQL_INSERT = 
        "INSERT INTO almacen (producto_id, cantidad_movimiento, usuario_id) VALUES (?, ?, ?)";
    private static final String SQL_SELECT_BY_ID = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id FROM almacen WHERE id = ?";
    private static final String SQL_SELECT_ALL = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id FROM almacen";
    private static final String SQL_UPDATE = 
        "UPDATE almacen SET producto_id = ?, cantidad_movimiento = ?, usuario_id = ? WHERE id = ? ";
    private static final String SQL_DELETE = 
        "DELETE FROM almacen WHERE id = ?";

    
    private Almacen mapResultSetToAlmacen(ResultSet rs) throws SQLException {
        Producto productoPlaceholder = new Producto();
        productoPlaceholder.setId(rs.getInt("producto_id"));
        Usuarios usuarioPlaceholder = new Usuarios();
        usuarioPlaceholder.setId(rs.getInt("usuario_id"));
        
        return new Almacen(
            rs.getInt("id"),
            productoPlaceholder,
            rs.getInt("cantidad_movimiento"),
            rs.getDate("fecha_entrada"),
            usuarioPlaceholder
        );
    }

   

    @Override
    public void crear(Almacen almacen) throws Exception {
       
        try (Connection conn = Config.getConnection()) {
           
            conn.setAutoCommit(true); 
            crearConConexion(conn, almacen);
        }
    }

  
    @Override
    public void crearConConexion(Connection conn, Almacen almacen) throws Exception {
      
        try (PreparedStatement stmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setInt(1, almacen.getProducto().getId());
            stmt.setInt(2, almacen.getCantidadEnAlmacen()); 
            stmt.setInt(3, almacen.getUsuario().getId());
            
            stmt.executeUpdate();
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    almacen.setId(rs.getInt(1));
                }
            }
        }
       
    }

    @Override
    public Almacen obtenerPorId(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToAlmacen(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Almacen> obtenerTodos() throws Exception {
        List<Almacen> almacenes = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            while (rs.next()) {
                almacenes.add(mapResultSetToAlmacen(rs));
            }
        }
        return almacenes;
    }

    @Override
    public void actualizar(Almacen almacen) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            
            stmt.setInt(1, almacen.getProducto().getId());
            stmt.setInt(2, almacen.getCantidadEnAlmacen()); 
            stmt.setInt(3, almacen.getUsuario().getId());
            stmt.setInt(4, almacen.getId());
            
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    @Override
    public List<Almacen> obtenerAlmacenesPorProductoId(int productoId) throws Exception {
      
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}