package com.mycompany.nativo.modelos;

import java.sql.Timestamp;

public class Usuarios {

    private int id;
    private String nombreUsuario;
    private String email; 
    private String contrasena; 
    private int rolId;
    private boolean activo; 
    private Timestamp fechaCreacion; 
    private String telefono; // Necesario para SMS

    public Usuarios(String nombreUsuario, String email, String contrasena, int rolId, String telefono) {
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.contrasena = contrasena;
        this.rolId = rolId;
        this.activo = true;
        this.telefono = telefono;
    }
    
    public Usuarios(int id, String nombreUsuario, String email, String contrasena, int rolId, boolean activo, Timestamp fechaCreacion, String telefono) {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.email = email;
        this.contrasena = contrasena;
        this.rolId = rolId;
        this.activo = activo;
        this.fechaCreacion = fechaCreacion;
        this.telefono = telefono;
    }

    public Usuarios() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public int getRolId() { return rolId; }
    public void setRolId(int rolId) { this.rolId = rolId; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
    public Timestamp getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Timestamp fechaCreacion) { this.fechaCreacion = fechaCreacion; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }

    @Override
    public String toString() {
        return "Usuarios{" + "id=" + id + ", user=" + nombreUsuario + ", email=" + email + ", tel=" + telefono + '}';
    }
}