package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Usuarios;
import com.mycompany.nativo.Config;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class UsuariosDaoJDBC implements UsuariosDao {

    private static final String SQL_SELECT_BASE = 
        "SELECT id, nombre_usuario, email, contraseña, rol_id, activo, fecha_creacion, telefono FROM usuarios";
    private static final String SQL_SELECT_BY_USERNAME = SQL_SELECT_BASE + " WHERE nombre_usuario = ?";
    private static final String SQL_SELECT_BY_EMAIL = SQL_SELECT_BASE + " WHERE email = ?";
    private static final String SQL_SELECT_BY_PHONE = SQL_SELECT_BASE + " WHERE telefono = ?";
    private static final String SQL_INSERT = "INSERT INTO usuarios (nombre_usuario, email, contraseña, rol_id, telefono) VALUES (?, ?, ?, ?, ?)";
    private static final String SQL_SELECT_ALL = SQL_SELECT_BASE;
    private static final String SQL_SELECT_BY_ID = SQL_SELECT_BASE + " WHERE id = ?";
    private static final String SQL_UPDATE = "UPDATE usuarios SET nombre_usuario = ?, email = ?, rol_id = ?, activo = ?, telefono = ? WHERE id = ?";
    private static final String SQL_DELETE = "DELETE FROM usuarios WHERE id = ?";
    private static final String SQL_UPDATE_PASSWORD = "UPDATE usuarios SET contraseña = ? WHERE id = ?";
        
    private Usuarios mapResultSetToUsuario(ResultSet rs) throws SQLException {
        return new Usuarios(
            rs.getInt("id"),
            rs.getString("nombre_usuario"),
            rs.getString("email"), 
            rs.getString("contraseña"),
            rs.getInt("rol_id"),
            rs.getBoolean("activo"), 
            rs.getTimestamp("fecha_creacion"),
            rs.getString("telefono") // Leer TELÉFONO
        );
    }

    @Override
    public Usuarios obtenerUsuarioPorTelefono(String telefono) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_PHONE)) {
            stmt.setString(1, telefono);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) usuario = mapResultSetToUsuario(rs);
            }
        }
        return usuario;
    }

    @Override
    public Usuarios obtenerUsuarioPorNombre(String nombreUsuario) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_USERNAME)) {
            stmt.setString(1, nombreUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) usuario = mapResultSetToUsuario(rs);
            }
        }
        return usuario;
    }

    @Override
    public Usuarios obtenerUsuarioPorEmail(String email) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_EMAIL)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) usuario = mapResultSetToUsuario(rs);
            }
        }
        return usuario;
    }

   @Override
    public int insertar(Usuarios usuario) throws SQLException {
        int registrosAfectados = 0;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT)) {
            stmt.setString(1, usuario.getNombreUsuario());
            stmt.setString(2, usuario.getEmail()); 
            stmt.setString(3, usuario.getContrasena()); 
            stmt.setInt(4, usuario.getRolId());
            stmt.setString(5, usuario.getTelefono()); // <-- GUARDAR TELÉFONO
            registrosAfectados = stmt.executeUpdate(); 
        }
        return registrosAfectados;
    }
    
    @Override
    public List<Usuarios> obtenerTodos() throws SQLException {
        List<Usuarios> usuarios = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            while (rs.next()) usuarios.add(mapResultSetToUsuario(rs));
        }
        return usuarios;
    }

    @Override
    public Usuarios obtenerUsuarioPorId(int id) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) usuario = mapResultSetToUsuario(rs);
            }
        }
        return usuario;
    }

    @Override
    public void actualizar(Usuarios usuario) throws SQLException {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            stmt.setString(1, usuario.getNombreUsuario());
            stmt.setString(2, usuario.getEmail()); 
            stmt.setInt(3, usuario.getRolId());
            stmt.setBoolean(4, usuario.isActivo());
            stmt.setString(5, usuario.getTelefono()); // <-- ACTUALIZAR TELÉFONO
            stmt.setInt(6, usuario.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws SQLException {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    @Override
    public void actualizarContrasena(Usuarios usuario) throws SQLException {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE_PASSWORD)) {
            stmt.setString(1, usuario.getContrasena()); 
            stmt.setInt(2, usuario.getId());
            stmt.executeUpdate();
        }
    }
}