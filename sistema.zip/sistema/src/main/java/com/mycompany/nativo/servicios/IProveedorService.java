package com.mycompany.nativo.servicios;

import com.mycompany.nativo.modelos.Proveedor;
import java.util.List;

public interface IProveedorService {
    void crearProveedor(Proveedor proveedor) throws Exception;
    Proveedor buscarProveedor(int id) throws Exception;
    List<Proveedor> listarProveedores() throws Exception;
    void actualizarProveedor(Proveedor proveedor) throws Exception;
    void eliminarProveedor(int id) throws Exception;
    
    // --- NUEVO (RF16) ---
    List<Proveedor> buscarProveedores(String termino) throws Exception;
}