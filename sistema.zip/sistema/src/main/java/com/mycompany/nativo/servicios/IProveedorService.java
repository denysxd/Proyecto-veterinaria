/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.nativo.servicios;

import com.mycompany.nativo.modelos.Proveedor;
import java.util.List;

public interface IProveedorService {
    void crearProveedor(Proveedor proveedor) throws Exception;
    Proveedor buscarProveedor(int id) throws Exception;
    List<Proveedor> listarProveedores() throws Exception;
    void actualizarProveedor(Proveedor proveedor) throws Exception;
    void eliminarProveedor(int id) throws Exception;
}