package com.mycompany.nativo.modelos;

import java.sql.Timestamp;

public class HistorialLogin {
    private int id;
    private int usuarioId;
    private String nombreUsuario; // Para mostrarlo fácil en el reporte
    private Timestamp fechaLogin;
    private String ipAddress;

    public HistorialLogin() {}

    public HistorialLogin(int id, int usuarioId, String nombreUsuario, Timestamp fechaLogin, String ipAddress) {
        this.id = id;
        this.usuarioId = usuarioId;
        this.nombreUsuario = nombreUsuario;
        this.fechaLogin = fechaLogin;
        this.ipAddress = ipAddress;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getUsuarioId() { return usuarioId; }
    public void setUsuarioId(int usuarioId) { this.usuarioId = usuarioId; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public Timestamp getFechaLogin() { return fechaLogin; }
    public void setFechaLogin(Timestamp fechaLogin) { this.fechaLogin = fechaLogin; }
    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    @Override
    public String toString() {
        return "Login{" + "user=" + nombreUsuario + ", fecha=" + fechaLogin + ", ip=" + ipAddress + '}';
    }
}