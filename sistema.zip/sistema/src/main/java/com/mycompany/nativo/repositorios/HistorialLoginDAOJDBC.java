package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.HistorialLogin;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HistorialLoginDAOJDBC implements IHistorialLoginDAO {

    private static final String SQL_INSERT = "INSERT INTO historial_login (usuario_id, ip_address) VALUES (?, ?)";
    private static final String SQL_SELECT_ALL = 
        "SELECT h.id, h.usuario_id, u.nombre_usuario, h.fecha_login, h.ip_address " +
        "FROM historial_login h " +
        "JOIN usuarios u ON h.usuario_id = u.id " +
        "ORDER BY h.fecha_login DESC";

    @Override
    public void registrarLogin(int usuarioId, String ipAddress) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT)) {
            stmt.setInt(1, usuarioId);
            stmt.setString(2, ipAddress);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<HistorialLogin> obtenerTodos() throws Exception {
        List<HistorialLogin> lista = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            while (rs.next()) {
                lista.add(new HistorialLogin(
                    rs.getInt("id"),
                    rs.getInt("usuario_id"),
                    rs.getString("nombre_usuario"),
                    rs.getTimestamp("fecha_login"),
                    rs.getString("ip_address")
                ));
            }
        }
        return lista;
    }
}