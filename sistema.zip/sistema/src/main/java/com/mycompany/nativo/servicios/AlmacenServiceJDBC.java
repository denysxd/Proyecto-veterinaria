package com.mycompany.nativo.servicios;


import com.mycompany.nativo.repositorios.IAlmacenDAO;
import com.mycompany.nativo.repositorios.AlmacenDAOJDBC;
import com.mycompany.nativo.modelos.Almacen; 
import java.util.List;

public class AlmacenServiceJDBC implements IAlmacenService {
    private IAlmacenDAO almacenDAO;

    public AlmacenServiceJDBC() {
        this.almacenDAO = new AlmacenDAOJDBC(); 
    }
    

    @Override
    public void registrarEntrada(Almacen registro) throws Exception {
      
        if (registro.getProducto() == null || registro.getProducto().getId() <= 0) {
            throw new Exception("El ID del producto es obligatorio y debe ser válido.");
        }
        if (registro.getUsuario() == null || registro.getUsuario().getId() <= 0) {
            throw new Exception("El usuario responsable del registro es obligatorio.");
        }
        if (registro.getCantidadEnAlmacen() <= 0) {
            throw new Exception("La cantidad de entrada debe ser mayor a cero.");
        }
        
        almacenDAO.crear(registro);
    }
    

    @Override
    public Almacen buscarRegistro(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de registro de inventario inválido.");
        }
        return almacenDAO.obtenerPorId(id);
    }


    @Override
    public List<Almacen> obtenerHistorial() throws Exception {
        return almacenDAO.obtenerTodos();
    }
    
  
    @Override
    public void actualizarRegistro(Almacen registro) throws Exception {
        if (registro.getId() <= 0) {
            throw new Exception("ID de registro inválido para actualizar.");
        }
        
    
        if (registro.getCantidadEnAlmacen() < 0) {
            throw new Exception("La cantidad no puede ser negativa.");
        }
        
        almacenDAO.actualizar(registro);
    }
    
 
    @Override
    public void eliminarRegistro(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de registro inválido para eliminar.");
        }
        almacenDAO.eliminar(id);
    }
}