package com.mycompany.nativo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import com.mycompany.nativo.servicios.*;
import com.mycompany.nativo.modelos.*;
import java.util.List;
import java.util.ArrayList;
import java.sql.Date;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;

public class Main {
    public static void main(String[] args) {
        
        // --- 1. PRUEBA DE CONEXIÓN ---
        try (Connection conn = Config.getConnection()) {
            if (conn != null) System.out.println("✅ Conexión DB Exitosa.");
        } catch (SQLException e) {
            System.err.println("❌ Error conexión DB: " + e.getMessage());
            return;
        }
        
        // --- 2. INICIALIZACIÓN DE SERVICIOS ---
        Scanner sc = new Scanner(System.in);
        UsuariosService usuarioService = new UsuariosService();
        IAlmacenService almacenService = new AlmacenServiceJDBC();
        IProductoService productoService = new ProductoServiceJDBC();
        ICategoriaService categoriaService = new CategoriaServiceJDBC();
        IProveedorService proveedorService = new ProveedorServiceJDBC(); 
        Usuarios usuarioLogeado = null; 

        // --- 3. LOGIN (Validación de menú corregida) ---
        System.out.println("=== LOGIN ===");
        while (usuarioLogeado == null) {
            System.out.println("1. Ingresar");
            System.out.println("2. Olvidé mi contraseña (RF30)");
            System.out.println("3. Salir");
            System.out.print("Opción: "); // Añadido para mejor UX
            String opLogin = sc.nextLine();
            
            if(opLogin.equals("3")) return;
            
            // --- LÓGICA DE RECUPERACIÓN (EMAIL O SMS) ---
            if(opLogin.equals("2")) {
                System.out.println("¿Cómo deseas recuperar tu contraseña?");
                System.out.println("1. Por Correo Electrónico (Email)");
                System.out.println("2. Por Mensaje de Texto (SMS)");
                System.out.print("Elige una opción: ");
                String metodo = sc.nextLine();
                boolean enviado = false;

                if (metodo.equals("1")) {
                    System.out.println("Ingrese su Email registrado:");
                    enviado = usuarioService.iniciarRecuperacion(sc.nextLine());
                } else if (metodo.equals("2")) {
                    System.out.println("Ingrese su Teléfono (ej: +51999888777):");
                    enviado = usuarioService.iniciarRecuperacionSMS(sc.nextLine());
                } else {
                    System.out.println("⚠️ Opción no válida.");
                }
                
                if (enviado) {
                    System.out.println("Ingrese el CÓDIGO recibido:");
                    String token = sc.nextLine();
                    System.out.println("Ingrese NUEVA contraseña:");
                    String newPass = sc.nextLine();
                    if(usuarioService.cambiarClaveConToken(token, newPass)) {
                        System.out.println("✅ Contraseña cambiada con éxito. Ahora inicie sesión.");
                    }
                }
                continue; // Vuelve al menú de login
            }
            
            // --- VALIDACIÓN AÑADIDA PARA CUALQUIER OTRA ENTRADA ---
            if (!opLogin.equals("1")) {
                System.out.println("⚠️ Opción no válida. Ingrese 1, 2, o 3.\n");
                continue; // Regresa al inicio del bucle
            }

            // Opción 1: Ingresar
            System.out.println("Email: "); String email = sc.nextLine(); 
            System.out.println("Contraseña: "); String pass = sc.nextLine();

            // RF39: Auditoría automática al loguearse
            usuarioLogeado = usuarioService.login(email, pass); 
            if (usuarioLogeado == null) System.out.println("⚠️ Credenciales incorrectas.");
        }
        
        System.out.println("\n¡Bienvenido, " + usuarioLogeado.getNombreUsuario() + "!");
        
        // --- RF34: PROCESO AUTOMÁTICO DE VENCIMIENTOS ---
        try {
            int afectados = productoService.procesarVencimientos();
            if (afectados > 0) {
                System.out.println("⚠️ ATENCIÓN: El sistema detectó " + afectados + " productos vencidos y los marcó como 'Vencido'.");
            }
        } catch (Exception e) { System.out.println("Error verificando vencimientos: " + e.getMessage()); }
        
        // --- RF37: DASHBOARD ---
        mostrarDashboard(usuarioLogeado, productoService);
        
        // --- MENÚS POR ROL ---
        if (usuarioLogeado.getRolId() == 1) {
            ejecutarMenuAdmin(sc, usuarioService, almacenService, productoService, categoriaService, proveedorService, usuarioLogeado);
        } else {
            ejecutarMenuUsuarioNormal(sc, almacenService, productoService, categoriaService, proveedorService, usuarioService, usuarioLogeado);
        }
        sc.close();
    }
    
    // --- DASHBOARD (RF37) ---
    public static void mostrarDashboard(Usuarios usuario, IProductoService prodService) {
        System.out.println("\n=================================================");
        System.out.println("   DASHBOARD - VETERINARIA (Usuario: " + usuario.getNombreUsuario() + ")");
        System.out.println("=================================================");
        try {
            List<Producto> stockBajo = prodService.obtenerAlertasStock(); 
            List<Producto> porVencer = prodService.obtenerAlertasVencimiento();
            List<Producto> todos = prodService.listarProductos();
            
            System.out.println("📦 Total Productos: " + todos.size());
            if (!stockBajo.isEmpty()) System.out.println("⚠️  ¡ALERTA! " + stockBajo.size() + " productos con STOCK BAJO.");
            if (!porVencer.isEmpty()) System.out.println("⏳ ¡ALERTA! " + porVencer.size() + " productos VENCEN PRONTO.");
        } catch (Exception e) {
            System.out.println("Error cargando dashboard: " + e.getMessage());
        }
        System.out.println("=================================================\n");
    }

    public static void ejecutarMenuAdmin(Scanner sc, UsuariosService us, IAlmacenService as, IProductoService ps, ICategoriaService cs, IProveedorService provs, Usuarios admin) {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n--- MENÚ ADMIN ---");
            System.out.println("1. Vender Producto (Salida)");
            System.out.println("2. Ingresar Stock (Entrada)");
            System.out.println("3. Ver Historial de Almacén (Filtros)");
            System.out.println("4. Consultar y BUSCAR Productos");
            System.out.println("5. Gestión de PRODUCTOS y CATEGORÍAS");
            System.out.println("6. Gestión de PROVEEDORES");
            System.out.println("7. Gestión de USUARIOS (Crear)"); 
            System.out.println("8. Administración de USUARIOS");
            System.out.println("9. Exportar Reporte a CSV (Excel)");
            System.out.println("10. Ver Auditoría de LOGIN (RF39)");
            System.out.println("0. Salir"); 
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1": registrarVenta(sc, ps, admin); break;
                case "2": registrarIngreso(sc, ps, admin); break;
                case "3": verHistorialAlmacen(sc, as, us); break; 
                case "4": buscarYListarProductos(sc, ps, cs, provs); break;
                case "5": ejecutarMenuProductos(sc, ps, cs, provs); break;
                case "6": ejecutarMenuProveedores(sc, provs, ps); break; 
                case "7": crearNuevoUsuario(sc, us); break;
                case "8": ejecutarMenuGestionUsuarios(sc, us, admin.getId()); break;
                case "9": exportarReporteCSV(ps); break;
                case "10": verAuditoriaLogin(us); break;
                case "0": salir = true; System.out.println("Cerrando sesión. ¡Hasta pronto!"); break;
                default: System.out.println("Opción no válida.");
            }
        }
    }
    
    public static void ejecutarMenuUsuarioNormal(Scanner sc, IAlmacenService as, IProductoService ps, ICategoriaService cs, IProveedorService pr, UsuariosService us, Usuarios user) {
        boolean salir = false;
        while (!salir) { 
            System.out.println("\n--- MENÚ USUARIO ---");
            System.out.println("1. Historial Almacén");
            System.out.println("2. Vender Producto");
            System.out.println("3. Consultar Productos");
            System.out.println("0. Salir");
            String opcionMenu = sc.nextLine();
            switch (opcionMenu) {
                case "1": verHistorialAlmacen(sc, as, us); break;
                case "2": registrarVenta(sc, ps, user); break;
                case "3": buscarYListarProductos(sc, ps, cs, pr); break;
                case "0": salir = true; System.out.println("Cerrando sesión."); break;
                default: System.out.println("Opción no válida.");
            }
        }
    }
    
    // --- AUDITORÍA (RF39) ---
    public static void verAuditoriaLogin(UsuariosService us) {
        System.out.println("\n--- AUDITORÍA DE ACCESOS (RF39) ---");
        try {
            List<HistorialLogin> lista = us.obtenerReporteAuditoria();
            if(lista.isEmpty()) System.out.println("No hay registros.");
            else {
                System.out.format("%-5s | %-15s | %-25s | %-15s%n", "ID", "USUARIO", "FECHA/HORA", "IP");
                System.out.println("-------------------------------------------------------------------");
                for(HistorialLogin h : lista) {
                    System.out.format("%-5d | %-15s | %-25s | %-15s%n", 
                        h.getId(), h.getNombreUsuario(), h.getFechaLogin(), h.getIpAddress());
                }
            }
        } catch(Exception e) { System.err.println("Error: " + e.getMessage()); }
    }

    // --- HISTORIAL CON FILTROS (RF24) ---
    public static void verHistorialAlmacen(Scanner sc, IAlmacenService as, UsuariosService us) {
        System.out.println("\n--- FILTROS DE HISTORIAL (RF24) ---");
        System.out.println("1. Todo  2. Por Producto  3. Por Usuario  4. Por Fechas");
        String opt = sc.nextLine();
        List<Almacen> h = new ArrayList<>();
        try {
            if (opt.equals("2")) {
                System.out.println("ID del Producto: ");
                int pid = Integer.parseInt(sc.nextLine());
                h = as.obtenerHistorialPorProducto(pid);
            } else if (opt.equals("3")) {
                us.listarUsuarios().forEach(u -> System.out.println(u.getId() + ". " + u.getNombreUsuario()));
                System.out.println("ID Usuario: ");
                int uid = Integer.parseInt(sc.nextLine());
                h = as.obtenerHistorialPorUsuario(uid);
            } else if (opt.equals("4")) {
                System.out.println("Inicio (Y-M-D): "); String i = sc.nextLine();
                System.out.println("Fin (Y-M-D): "); String f = sc.nextLine();
                h = as.obtenerHistorialPorRangoFechas(i, f);
            } else h = as.obtenerHistorial();

            if (h.isEmpty()) System.out.println("Sin registros.");
            else {
                System.out.format("%-5s | %-10s | %-8s | %-15s | %-15s%n", "ID", "PROD", "CANT", "MOTIVO", "FECHA");
                for (Almacen r : h) {
                    System.out.format("%-5d | %-10d | %-8d | %-15s | %-15s%n", 
                        r.getId(), (r.getProducto() != null ? r.getProducto().getId() : 0), 
                        r.getCantidadEnAlmacen(), recortar(r.getMotivo(), 15), r.getFechaEntrada());
                }
            }
        } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }
    
    // --- CONSULTA PRODUCTOS (RF7 + RF38) ---
    public static void buscarYListarProductos(Scanner sc, IProductoService ps, ICategoriaService cs, IProveedorService pr) {
        System.out.println("\n1. Todo  2. Buscar  3. Filtrar Categoría (RF7)  4. Búsqueda Avanzada (RF38)");
        String opt = sc.nextLine();
        try {
            List<Producto> l = new ArrayList<>();
            if (opt.equals("2")) {
                System.out.println("Buscar: "); l = ps.buscarProductos(sc.nextLine());
            } else if (opt.equals("3")) {
                cs.listarCategorias().forEach(c -> System.out.println(c.getId() + ". " + c.getNombre()));
                System.out.println("ID Cat: "); l = ps.listarProductosPorCategoria(Integer.parseInt(sc.nextLine()));
            } else if (opt.equals("4")) {
                realizarBusquedaAvanzada(sc, ps, cs, pr);
                return;
            } else l = ps.listarProductos();

            mostrarListaProductos(l);
        } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }
    
    public static void realizarBusquedaAvanzada(Scanner sc, IProductoService ps, ICategoriaService cs, IProveedorService pr) {
        try {
            System.out.println("--- BÚSQUEDA AVANZADA (Enter para saltar) ---");
            System.out.println("Nombre contiene: "); String n = sc.nextLine();
            
            System.out.println("Filtrar Categoría? (S/N): "); int cid = 0;
            if(sc.nextLine().equalsIgnoreCase("S")) {
                cs.listarCategorias().forEach(c->System.out.println(c.getId()+"."+c.getNombre()));
                System.out.println("ID: "); try{cid=Integer.parseInt(sc.nextLine());}catch(Exception e){}
            }
            
            System.out.println("Filtrar Proveedor? (S/N): "); int pid = 0;
            if(sc.nextLine().equalsIgnoreCase("S")) {
                pr.listarProveedores().forEach(p->System.out.println(p.getId()+"."+p.getNombre()));
                System.out.println("ID: "); try{pid=Integer.parseInt(sc.nextLine());}catch(Exception e){}
            }
            
            System.out.println("Solo Stock Bajo? (S/N): "); boolean sb = sc.nextLine().equalsIgnoreCase("S");
            
            List<Producto> res = ps.buscarProductosAvanzado(n, cid, pid, sb);
            mostrarListaProductos(res);
            
        } catch(Exception e) { System.err.println(e.getMessage()); }
    }
    
    public static void mostrarListaProductos(List<Producto> l) {
        if(l.isEmpty()) System.out.println("Sin resultados.");
        else {
            System.out.format("%-5s | %-20s | %-8s | %-10s | %-15s%n", "ID", "NOMBRE", "STOCK", "ESTADO", "PROV");
            for (Producto p : l) {
                String pr = (p.getProveedor() != null) ? p.getProveedor().getNombre() : "N/A";
                System.out.format("%-5d | %-20s | %-8d | %-10s | %-15s%n", 
                    p.getId(), recortar(p.getNombre(), 20), p.getCantidad(), p.getEstado(), recortar(pr, 15));
            }
        }
    }
    
    private static String recortar(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n-3) + "..." : s;
    }

    public static void exportarReporteCSV(IProductoService prodService) {
        try {
            List<Producto> lista = prodService.listarProductos();
            OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("Reporte_Inventario_Completo.csv"), StandardCharsets.UTF_8);
            writer.write('\ufeff'); 
            writer.write("ID;Producto;Categoria;Proveedor;Stock Actual;Stock Minimo;Estado;Precio;Ultima Modificacion;Fecha Caducidad\n");
            
            for (Producto p : lista) {
                String cat = (p.getCategoria() != null) ? p.getCategoria().getNombre() : "Sin Cat";
                String prov = (p.getProveedor() != null) ? p.getProveedor().getNombre() : "Sin Prov";
                String fechaMod = (p.getFechaUltimaModificacion() != null) ? p.getFechaUltimaModificacion().toString() : "N/A";
                
                String linea = String.format("%d;%s;%s;%s;%d;%d;%s;%.2f;%s;%s\n",
                    p.getId(), p.getNombre(), cat, prov, p.getCantidad(), p.getStockMinimo(), p.getEstado(), p.getPrecio(), fechaMod, p.getFechaCaducidad());
                writer.write(linea);
            }
            writer.flush(); writer.close();
            System.out.println("✅ Reporte generado: 'Reporte_Inventario_Completo.csv'");
        } catch (Exception e) {
            System.err.println("❌ Error al exportar: " + e.getMessage());
        }
    }

    public static void ejecutarMenuProductos(Scanner sc, IProductoService ps, ICategoriaService cs, IProveedorService provs) {
        boolean b = false;
        while(!b) {
            System.out.println("\n1.Crear Prod 2.Crear Cat 3.Editar Prod 4.Volver");
            String op = sc.nextLine();
            if(op.equals("1")) crearNuevoProducto(sc, ps, cs, provs);
            else if(op.equals("2")) crearNuevaCategoria(sc, cs);
            else if(op.equals("3")) actualizarProductoExistente(sc, ps, cs, provs);
            else if(op.equals("4")) b = true;
        }
    }

    public static void actualizarProductoExistente(Scanner sc, IProductoService ps, ICategoriaService cs, IProveedorService provs) {
        try {
            System.out.println("ID Prod: "); Producto p = ps.buscarProducto(Integer.parseInt(sc.nextLine()));
            if(p == null) return;
            
            System.out.println("Nombre ("+p.getNombre()+"): "); String n = sc.nextLine(); if(!n.isEmpty()) p.setNombre(n);
            System.out.println("Min Stock ("+p.getStockMinimo()+"): "); String m = sc.nextLine(); if(!m.isEmpty()) p.setStockMinimo(Integer.parseInt(m));
            
            ps.actualizarProducto(p);
            System.out.println("✅ Actualizado.");
        } catch(Exception e) { System.err.println(e.getMessage()); }
    }

    public static void crearNuevoProducto(Scanner sc, IProductoService ps, ICategoriaService cs, IProveedorService provs) {
        try {
            System.out.println("Nombre: "); String n = sc.nextLine();
            System.out.println("Precio: "); double p = Double.parseDouble(sc.nextLine());
            System.out.println("Stock: "); int c = Integer.parseInt(sc.nextLine());
            System.out.println("Min Stock (RF17): "); int min = Integer.parseInt(sc.nextLine());
            System.out.println("Fabricación (Y-M-D): "); Date f = Date.valueOf(sc.nextLine());
            System.out.println("Caducidad (Y-M-D): "); Date cad = Date.valueOf(sc.nextLine());
            
            cs.listarCategorias().forEach(ca -> System.out.println(ca.getId()+"."+ca.getNombre()));
            System.out.println("ID Cat: "); int cid = Integer.parseInt(sc.nextLine());
            provs.listarProveedores().forEach(pr -> System.out.println(pr.getId()+"."+pr.getNombre()));
            System.out.println("ID Prov: "); int pid = Integer.parseInt(sc.nextLine());
            
            Categoria cat = cs.buscarCategoria(cid);
            Proveedor prov = provs.buscarProveedor(pid);
            if(cat != null && prov != null) {
                ps.crearProducto(new Producto(n, c, p, f, cad, cat, prov, min)); 
            }
        } catch(Exception e) { System.err.println(e.getMessage()); }
    }

    public static void crearNuevaCategoria(Scanner sc, ICategoriaService cs) {
         try {
             System.out.println("Nombre: "); cs.crearCategoria(new Categoria(sc.nextLine()));
             System.out.println("✅ Creada.");
         } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }

public static void crearNuevoUsuario(Scanner sc, UsuariosService us) {
        try {
            System.out.println("User: "); 
            String u = sc.nextLine();
            
            System.out.println("Email: "); 
            String e = sc.nextLine();
            
            System.out.println("Pass: "); 
            String p = sc.nextLine();
            
            System.out.println("Teléfono (+51xxxxxxxxx): "); // Preguntamos por el teléfono
            String t = sc.nextLine(); // <-- Guardamos el teléfono aquí
            
            System.out.println("Rol(1=A,2=U): "); 
            int r = Integer.parseInt(sc.nextLine());
            
            // CORRECCIÓN: Ahora llamamos al servicio con los 5 argumentos (u, e, p, r, t)
            if(us.crearUsuario(u, e, p, r, t)) {
                System.out.println("✅ Usuario creado.");
            } else {
                System.err.println("❌ Error al crear usuario.");
            }
        } catch(Exception e) { 
            System.err.println("Error: " + e.getMessage()); 
        }
    }
    public static void ejecutarMenuGestionUsuarios(Scanner sc, UsuariosService us, int adminId) {
        try {
            System.out.println("1. Listar  2. Eliminar");
            if(sc.nextLine().equals("1")) us.listarUsuarios().forEach(System.out::println);
            else { System.out.println("ID: "); us.eliminarUsuario(Integer.parseInt(sc.nextLine()), adminId); }
        } catch(Exception e) { System.err.println(e.getMessage()); }
    }

    public static void ejecutarMenuProveedores(Scanner sc, IProveedorService ps, IProductoService prodService) {
        boolean v = false;
        while(!v) {
            System.out.println("\n--- GESTIÓN PROVEEDORES ---");
            System.out.println("1. Crear  2. Listar  3. Buscar  4. Ver Prod  5. Eliminar  6. Modificar (RF14)  7. Volver");
            String op = sc.nextLine();
            try {
                if(op.equals("1")) {
                    System.out.println("Nombre: "); ps.crearProveedor(new Proveedor(sc.nextLine(), "", "", ""));
                    System.out.println("Creado.");
                } else if(op.equals("2")) {
                    ps.listarProveedores().forEach(p -> System.out.println(p.getId() + " - " + p.getNombre()));
                } else if(op.equals("3")) {
                    System.out.println("Buscar: "); ps.buscarProveedores(sc.nextLine()).forEach(p -> System.out.println(p.getNombre()));
                } else if(op.equals("4")) {
                    System.out.println("ID Prov: "); prodService.listarProductosPorProveedor(Integer.parseInt(sc.nextLine())).forEach(p -> System.out.println(p.getNombre()));
                } else if(op.equals("5")) {
                    System.out.println("ID Eliminar: "); ps.eliminarProveedor(Integer.parseInt(sc.nextLine()));
                    System.out.println("✅ Eliminado.");
                } else if(op.equals("6")) { 
                    actualizarProveedor(sc, ps); 
                } else if(op.equals("7")) v = true;
            } catch(Exception e) { System.err.println(e.getMessage()); }
        }
    }

    public static void actualizarProveedor(Scanner sc, IProveedorService ps) {
        try {
            System.out.println("ID a editar: "); int id = Integer.parseInt(sc.nextLine());
            Proveedor p = ps.buscarProveedor(id);
            if (p == null) { System.out.println("❌ No existe."); return; }
            
            System.out.println("Actual: " + p.getNombre() + ". Nuevo (Enter mantiene): ");
            String n = sc.nextLine(); if(!n.isEmpty()) p.setNombre(n);
            System.out.println("RUC: "); String r = sc.nextLine(); if(!r.isEmpty()) p.setRuc(r);
            System.out.println("Tel: "); String t = sc.nextLine(); if(!t.isEmpty()) p.setTelefono(t);
            System.out.println("Dir: "); String d = sc.nextLine(); if(!d.isEmpty()) p.setDireccion(d);
            
            ps.actualizarProveedor(p);
            System.out.println("✅ Actualizado.");
        } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }
    
    public static void registrarVenta(Scanner sc, IProductoService ps, Usuarios user) {
        try {
            System.out.println("ID Prod: "); int pid = Integer.parseInt(sc.nextLine());
            System.out.println("Cant: "); int cant = Integer.parseInt(sc.nextLine());
            System.out.println("Motivo (1.Venta 2.Caducidad 3.Otro): ");
            String m = sc.nextLine();
            String motivo = m.equals("2") ? "Caducidad" : (m.equals("3") ? "Uso Interno" : "Venta");
            
            Producto p = new Producto(); p.setId(pid);
            Almacen a = new Almacen(p, cant, user, motivo);
            ps.registrarMovimientoInventario(a, false); 
            System.out.println("✅ Salida registrada.");
        } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }
    
    public static void registrarIngreso(Scanner sc, IProductoService ps, Usuarios user) {
        try {
            System.out.println("ID Prod: "); int pid = Integer.parseInt(sc.nextLine());
            System.out.println("Cant: "); int cant = Integer.parseInt(sc.nextLine());
            Producto p = new Producto(); p.setId(pid);
            Almacen a = new Almacen(p, cant, user, "Compra");
            ps.registrarMovimientoInventario(a, true); 
            System.out.println("✅ Ingreso registrado.");
        } catch (Exception e) { System.err.println("Error: " + e.getMessage()); }
    }
}