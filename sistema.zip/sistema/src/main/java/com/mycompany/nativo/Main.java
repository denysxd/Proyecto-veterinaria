package com.mycompany.nativo;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import com.mycompany.nativo.servicios.UsuariosService;
import com.mycompany.nativo.modelos.Usuarios;

// Importaciones de todos los Servicios y Modelos necesarios
import com.mycompany.nativo.servicios.IAlmacenService;
import com.mycompany.nativo.servicios.AlmacenServiceJDBC;
import com.mycompany.nativo.servicios.IProductoService;
import com.mycompany.nativo.servicios.ProductoServiceJDBC;
import com.mycompany.nativo.servicios.ICategoriaService;
import com.mycompany.nativo.servicios.CategoriaServiceJDBC;
import com.mycompany.nativo.servicios.IProveedorService; 
import com.mycompany.nativo.servicios.ProveedorServiceJDBC; 
import com.mycompany.nativo.modelos.Almacen;
import com.mycompany.nativo.modelos.Producto;
import com.mycompany.nativo.modelos.Categoria;
import com.mycompany.nativo.modelos.Proveedor; 
import java.util.List;
import java.sql.Date; 

public class Main {
    public static void main(String[] args) {
        
        // --- 1. PRUEBA DE CONEXIÓN ---
        Connection testConn = null;
        try {
            System.out.println("Intentando conectar a la base de datos...");
            testConn = Config.getConnection();
            if (testConn != null) {
                System.out.println("✅ ¡Conexión exitosa! ✅\n");
            } else {
                System.out.println("❌ Fallo en la conexión. Terminando programa.");
                return;
            }
        } catch (SQLException e) {
            System.out.println("❌ Fallo en la conexión SQL. Terminando programa.");
            System.err.println("Detalle del error: " + e.getMessage());
            return;
        } finally {
            if (testConn != null) {
                try { testConn.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
        }
        
        // --- 2. INICIALIZACIÓN DE SERVICIOS ---
        Scanner sc = new Scanner(System.in);
        UsuariosService usuarioService = new UsuariosService();
        IAlmacenService almacenService = new AlmacenServiceJDBC();
        IProductoService productoService = new ProductoServiceJDBC();
        ICategoriaService categoriaService = new CategoriaServiceJDBC();
        IProveedorService proveedorService = new ProveedorServiceJDBC(); 
        Usuarios usuarioLogeado = null; 

        // --- 3. LÓGICA DE LOGIN (USA EMAIL) ---
        System.out.println("=== Login ===");
        
        while (usuarioLogeado == null) {
            System.out.println("Email (o 'salir' para terminar): ");
            String email = sc.nextLine(); 

            if (email.equalsIgnoreCase("salir")) {
                System.out.println("Terminando programa.");
                sc.close();
                return; 
            }

            System.out.println("Contraseña: ");
            String pass = sc.nextLine();

            usuarioLogeado = usuarioService.login(email, pass); 

            if (usuarioLogeado == null) {
                System.out.println("\n⚠️ Email o contraseña incorrectos. Inténtelo de nuevo.\n");
            }
        }
        
        // --- INICIO DEL FLUJO POST-LOGIN ---
        
        System.out.println("\n¡Bienvenido, " + usuarioLogeado.getNombreUsuario() + "!");
        int rolBase = usuarioLogeado.getRolId();
        
        System.out.println("\n¿CÓMO DESEA INGRESAR?");
        System.out.println("1. Como Administrador (Acceso total)");
        System.out.println("2. Como Usuario normal (Acceso limitado)");
        System.out.println("Elige una opción (1 o 2): ");
        String opcionIngreso = sc.nextLine();
        
        if (opcionIngreso.equals("1")) {
            if (rolBase == 1) { // Rol 1 = Admin
                System.out.println("\n--- Modo: ADMINISTRADOR ---");
                ejecutarMenuAdmin(sc, usuarioService, almacenService, productoService, categoriaService, proveedorService, usuarioLogeado);
            } else {
                System.err.println("\n⛔ ACCESO DENEGADO: No tiene los permisos de Administrador.");
            }
        } else if (opcionIngreso.equals("2")) {
            System.out.println("\n--- Modo: USUARIO NORMAL ---");
            ejecutarMenuUsuarioNormal(sc, almacenService, productoService, usuarioLogeado);
        } else {
            System.out.println("Opción no válida. Se cerrará la sesión.");
        }
        
        sc.close();
    }
    
    // =================================================================
    //                    MÉTODOS AUXILIARES DE MENÚS
    // =================================================================
    
    public static void ejecutarMenuAdmin(Scanner sc, UsuariosService usuarioService, IAlmacenService almacenService, IProductoService productoService, ICategoriaService categoriaService, IProveedorService proveedorService, Usuarios usuarioAdmin) {
        boolean salir = false;
        while (!salir) {
            System.out.println("\n-------------------------------------------");
            System.out.println("Menú de Administrador:");
            System.out.println("1. Vender Producto (Salida)");
            System.out.println("2. Ingresar Stock (Entrada)");
            System.out.println("3. Ver Historial de Almacén");
            System.out.println("4. Consultar Stock de Productos"); // <-- Opción añadida para Admin
            System.out.println("5. Gestión de PRODUCTOS y CATEGORÍAS");
            System.out.println("6. Gestión de PROVEEDORES");
            System.out.println("7. Gestión de USUARIOS (Crear)"); 
            System.out.println("8. Administración de USUARIOS (Listar/Editar/Eliminar)"); 
            System.out.println("9. Salir de la aplicación"); 
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1":
                    registrarVenta(sc, productoService, usuarioAdmin); 
                    break;
                case "2":
                    registrarIngreso(sc, productoService, usuarioAdmin);
                    break;
                case "3":
                    verHistorialAlmacen(almacenService);
                    break;
                case "4":
                    // <-- Llamada a la función
                    consultarStockProductos(productoService);
                    break;
                case "5":
                    ejecutarMenuProductos(sc, productoService, categoriaService, proveedorService);
                    break;
                case "6":
                    ejecutarMenuProveedores(sc, proveedorService);
                    break;
                case "7":
                    crearNuevoUsuario(sc, usuarioService);
                    break;
                case "8":
                    ejecutarMenuGestionUsuarios(sc, usuarioService, usuarioAdmin.getId());
                    break;
                case "9":
                    salir = true;
                    System.out.println("Cerrando sesión. ¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }
    
    public static void ejecutarMenuUsuarioNormal(Scanner sc, IAlmacenService almacenService, IProductoService productoService, Usuarios usuarioLogeado) {
        boolean salir = false;
        while (!salir) { 
            System.out.println("\n-------------------------------------------");
            System.out.println("Menú de Usuario:");
            System.out.println("1. Consultar Historial de Almacén");
            System.out.println("2. Vender Producto");
            System.out.println("3. Consultar Stock de Productos");
            System.out.println("4. Salir de la aplicación");
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1":
                    verHistorialAlmacen(almacenService);
                    break;
                case "2":
                    registrarVenta(sc, productoService, usuarioLogeado);
                    break;
                case "3":
                    consultarStockProductos(productoService);
                    break;
                case "4":
                    salir = true;
                    System.out.println("Cerrando sesión. ¡Hasta pronto!");
                    break;
                default:
                    System.out.println("Opción no válida. Inténtalo de nuevo.");
            }
        }
    }
    
    // =================================================================
    //              LÓGICA DE GESTIÓN DE PRODUCTOS Y CATEGORÍAS
    // =================================================================
    
    public static void ejecutarMenuProductos(Scanner sc, IProductoService productoService, ICategoriaService categoriaService, IProveedorService proveedorService) {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- GESTIÓN DE PRODUCTOS Y CATEGORÍAS ---");
            System.out.println("1. Crear Nuevo Producto");
            System.out.println("2. Crear Nueva Categoría");
            System.out.println("3. Actualizar Producto Existente"); 
            System.out.println("4. Volver al menú de Administrador");
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1":
                    crearNuevoProducto(sc, productoService, categoriaService, proveedorService);
                    break;
                case "2":
                    crearNuevaCategoria(sc, categoriaService);
                    break;
                case "3":
                    actualizarProductoExistente(sc, productoService, categoriaService, proveedorService);
                    break;
                case "4":
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }

    public static void actualizarProductoExistente(Scanner sc, IProductoService productoService, ICategoriaService categoriaService, IProveedorService proveedorService) {
        System.out.println("\n--- ACTUALIZAR PRODUCTO ---");
        try {
            System.out.println("Introduce el ID del producto a actualizar: ");
            int id = Integer.parseInt(sc.nextLine());
            
            Producto producto = productoService.buscarProducto(id);
            if (producto == null) {
                System.err.println("❌ Error: Producto no encontrado con ID: " + id);
                return;
            }

            System.out.println("Datos actuales: " + producto);
            System.out.println("Introduce los NUEVOS datos (o presiona ENTER para mantener el valor actual):");

            System.out.println("Nuevo Nombre (Actual: " + producto.getNombre() + "): ");
            String nombre = sc.nextLine();
            if (!nombre.trim().isEmpty()) {
                producto.setNombre(nombre);
            }

            System.out.println("Nuevo Precio (Actual: " + producto.getPrecio() + "): ");
            String precioStr = sc.nextLine();
            if (!precioStr.trim().isEmpty()) {
                producto.setPrecio(Double.parseDouble(precioStr));
            }

            System.out.println("Nueva Cantidad (Stock) (Actual: " + producto.getCantidad() + "): ");
            String cantidadStr = sc.nextLine();
            if (!cantidadStr.trim().isEmpty()) {
                producto.setCantidad(Integer.parseInt(cantidadStr));
            }
            
            System.out.println("Nueva Fecha Fabricación (Actual: " + producto.getFechaFabricacion() + ") (YYYY-MM-DD): ");
            String fabStr = sc.nextLine();
            if (!fabStr.trim().isEmpty()) {
                producto.setFechaFabricacion(Date.valueOf(fabStr));
            }
            System.out.println("Nueva Fecha Caducidad (Actual: " + producto.getFechaCaducidad() + ") (YYYY-MM-DD): ");
            String cadStr = sc.nextLine();
            if (!cadStr.trim().isEmpty()) {
                producto.setFechaCaducidad(Date.valueOf(cadStr));
            }

            List<Categoria> categorias = categoriaService.listarCategorias();
            System.out.println("\n--- CATEGORÍAS DISPONIBLES ---");
            categorias.forEach(c -> System.out.println(c.getId() + ". " + c.getNombre()));
            System.out.println("Nuevo ID de Categoría (Actual: " + producto.getCategoriaId() + "): ");
            String catIdStr = sc.nextLine();
            if (!catIdStr.trim().isEmpty()) {
                int categoriaId = Integer.parseInt(catIdStr);
                Categoria categoriaSeleccionada = categoriaService.buscarCategoria(categoriaId);
                if (categoriaSeleccionada == null) {
                    System.err.println("⚠️ ID de categoría no encontrado. Se mantendrá la original.");
                } else {
                    producto.setCategoria(categoriaSeleccionada);
                    producto.setCategoriaId(categoriaSeleccionada.getId()); 
                }
            }
            
            List<Proveedor> proveedores = proveedorService.listarProveedores();
            System.out.println("\n--- PROVEEDORES DISPONIBLES ---");
            proveedores.forEach(p -> System.out.println(p.getId() + ". " + p.getNombre()));
            System.out.println("Nuevo ID de Proveedor (Actual: " + producto.getProveedorId() + "): ");
            String provIdStr = sc.nextLine();
            if (!provIdStr.trim().isEmpty()) {
                int proveedorId = Integer.parseInt(provIdStr);
                Proveedor proveedorSeleccionado = proveedorService.buscarProveedor(proveedorId);
                if (proveedorSeleccionado == null) {
                    System.err.println("⚠️ ID de proveedor no encontrado. Se mantendrá el original.");
                } else {
                    producto.setProveedor(proveedorSeleccionado);
                    producto.setProveedorId(proveedorSeleccionado.getId()); 
                }
            }

            productoService.actualizarProducto(producto);
            System.out.println("✅ Producto actualizado correctamente.");

        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (IllegalArgumentException e) {
             System.err.println("❌ Error: Formato de fecha inválido. Usa YYYY-MM-DD.");
        } catch (Exception e) {
            System.err.println("❌ Error de negocio o base de datos: " + e.getMessage());
        }
    }


    public static void crearNuevoProducto(Scanner sc, IProductoService productoService, ICategoriaService categoriaService, IProveedorService proveedorService) {
        System.out.println("\n--- CREAR NUEVO PRODUCTO ---");
        try {
            System.out.println("Nombre del Producto: ");
            String nombre = sc.nextLine();
            System.out.println("Precio: ");
            double precio = Double.parseDouble(sc.nextLine());
            System.out.println("Stock Inicial (Cantidad): ");
            int cantidad = Integer.parseInt(sc.nextLine());
            System.out.println("Fecha Fabricación (YYYY-MM-DD): ");
            Date fechaFabricacion = Date.valueOf(sc.nextLine());
            System.out.println("Fecha Caducidad (YYYY-MM-DD): ");
            Date fechaCaducidad = Date.valueOf(sc.nextLine());
            
            List<Categoria> categorias = categoriaService.listarCategorias();
            if (categorias.isEmpty()) {
                System.err.println("❌ ERROR: No hay categorías registradas. Crea una primero.");
                return;
            }
            System.out.println("\n--- CATEGORÍAS DISPONIBLES ---");
            categorias.forEach(c -> System.out.println(c.getId() + ". " + c.getNombre()));
            System.out.println("Introduce el ID de la Categoría: ");
            int categoriaId = Integer.parseInt(sc.nextLine());
            Categoria categoriaSeleccionada = categoriaService.buscarCategoria(categoriaId);
            if (categoriaSeleccionada == null) {
                System.err.println("❌ Error: ID de categoría no encontrado.");
                return;
            }
            
            List<Proveedor> proveedores = proveedorService.listarProveedores();
            if (proveedores.isEmpty()) {
                System.err.println("❌ ERROR: No hay proveedores registrados. Crea uno primero.");
                return;
            }
            System.out.println("\n--- PROVEEDORES DISPONIBLES ---");
            proveedores.forEach(p -> System.out.println(p.getId() + ". " + p.getNombre()));
            System.out.println("Introduce el ID del Proveedor: ");
            int proveedorId = Integer.parseInt(sc.nextLine());
            Proveedor proveedorSeleccionado = proveedorService.buscarProveedor(proveedorId);
            if (proveedorSeleccionado == null) {
                System.err.println("❌ Error: ID de proveedor no encontrado.");
                return;
            }
            
            Producto nuevoProducto = new Producto(
                nombre, cantidad, precio, 
                fechaFabricacion, fechaCaducidad, 
                categoriaSeleccionada,
                proveedorSeleccionado 
            );
            
            productoService.crearProducto(nuevoProducto);
            System.out.println("✅ Producto '" + nombre + "' creado correctamente.");
            
        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (IllegalArgumentException e) {
             System.err.println("❌ Error: Formato de fecha inválido. Usa YYYY-MM-DD.");
        } catch (Exception e) {
            System.err.println("❌ Error de negocio o base de datos: " + e.getMessage());
        }
    }

    public static void crearNuevaCategoria(Scanner sc, ICategoriaService categoriaService) {
         System.out.println("\n--- CREAR NUEVA CATEGORÍA ---");
         System.out.println("Nombre de la nueva categoría: ");
         String nombre = sc.nextLine();
         try {
             Categoria nuevaCategoria = new Categoria(nombre);
             categoriaService.crearCategoria(nuevaCategoria);
             System.out.println("✅ Categoría '" + nombre + "' creada con ID: " + nuevaCategoria.getId());
         } catch (Exception e) {
             System.err.println("❌ Error al crear categoría: " + e.getMessage());
         }
    }
    
    // =================================================================
    //                    LÓGICA DE ALMACÉN Y USUARIOS
    // =================================================================
    
    public static void registrarVenta(Scanner sc, IProductoService productoService, Usuarios responsable) {
        System.out.println("\n--- REGISTRAR VENTA (SALIDA DE ALMACÉN) ---");
        
        System.out.println("ID del producto a vender: "); 
        int productoId;
        try {
            productoId = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("❌ ID de Producto inválido.");
            return;
        }

        System.out.println("Cantidad a VENDER (ej. 50): "); 
        int cantidad;
        try {
            cantidad = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("❌ Cantidad inválida.");
            return;
        }

        try {
            Producto productoPlaceholder = new Producto();
            productoPlaceholder.setId(productoId);
            Almacen nuevoRegistro = new Almacen(productoPlaceholder, cantidad, responsable);
            
            productoService.registrarMovimientoInventario(nuevoRegistro, false); 
            
            System.out.println("✅ Venta registrada. Stock actualizado correctamente.");
            
        } catch (Exception e) {
            System.err.println("❌ Error al registrar la venta: " + e.getMessage());
            System.err.println("   (La transacción fue revertida. El stock no ha cambiado.)");
        }
    }
    
    public static void registrarIngreso(Scanner sc, IProductoService productoService, Usuarios responsable) {
        System.out.println("\n--- REGISTRAR INGRESO (ENTRADA DE ALMACÉN) ---");
        
        System.out.println("ID del producto a ingresar: "); 
        int productoId;
        try {
            productoId = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("❌ ID de Producto inválido.");
            return;
        }

        System.out.println("Cantidad a INGRESAR (ej. 100): "); 
        int cantidad;
        try {
            cantidad = Integer.parseInt(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("❌ Cantidad inválida.");
            return;
        }

        try {
            Producto productoPlaceholder = new Producto();
            productoPlaceholder.setId(productoId);
            Almacen nuevoRegistro = new Almacen(productoPlaceholder, cantidad, responsable);
            
            productoService.registrarMovimientoInventario(nuevoRegistro, true); 
            
            System.out.println("✅ Ingreso registrado. Stock actualizado correctamente.");
            
        } catch (Exception e) {
            System.err.println("❌ Error al registrar el ingreso: " + e.getMessage());
            System.err.println("   (La transacción fue revertida. El stock no ha cambiado.)");
        }
    }
    
    public static void verHistorialAlmacen(IAlmacenService almacenService) {
        try {
            List<Almacen> historial = almacenService.obtenerHistorial();
            System.out.println("\n--- HISTORIAL DE MOVIMIENTOS ---");
            
            if (historial.isEmpty()) {
                System.out.println("No hay registros de inventario.");
                return;
            }
            
            System.out.println(String.format("%-5s | %-12s | %-10s | %-12s | %-10s", 
                "ID", "Producto ID", "Cantidad", "Usuario ID", "Fecha"));
            System.out.println("----------------------------------------------------------------");
            
            historial.forEach(r -> {
                System.out.println(String.format("%-5d | %-12d | %-10d | %-12d | %-10s", 
                                                r.getId(), 
                                                (r.getProducto() != null ? r.getProducto().getId() : 0), 
                                                r.getCantidadEnAlmacen(),
                                                (r.getUsuario() != null ? r.getUsuario().getId() : 0),
                                                r.getFechaEntrada()));
            });
            
        } catch (Exception e) {
            System.err.println("❌ Error al obtener historial: " + e.getMessage());
        }
    }
    
    public static void consultarStockProductos(IProductoService productoService) {
        System.out.println("\n--- CONSULTA DE STOCK DE PRODUCTOS ---");
        try {
            List<Producto> productos = productoService.listarProductos();
            if (productos.isEmpty()) {
                System.out.println("No hay productos registrados.");
                return;
            }
            
            System.out.println(String.format("%-5s | %-30s | %-10s", "ID", "Producto", "Stock Actual"));
            System.out.println("-----------------------------------------------------");
            productos.forEach(p -> {
                System.out.println(String.format("%-5d | %-30s | %-10d", 
                                                p.getId(), 
                                                p.getNombre(), 
                                                p.getCantidad()));
            });
            
        } catch (Exception e) {
            System.err.println("❌ Error al consultar stock: " + e.getMessage());
        }
    }

    public static void crearNuevoUsuario(Scanner sc, UsuariosService usuarioService) {
        System.out.println("\n--- CREAR NUEVO USUARIO (RF27/28) ---");
        System.out.println("Nombre nuevo usuario: ");
        String nuevoUser = sc.nextLine();
        
        System.out.println("Email del usuario: ");
        String email = sc.nextLine();
        
        System.out.println("Contraseña (temporal): ");
        String nuevaPass = sc.nextLine();
        
        System.out.println("Rol (1=admin, 2=usuario): ");
        int rolId;
        try {
            rolId = Integer.parseInt(sc.nextLine());
            if(rolId != 1 && rolId != 2) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            System.out.println("⚠️ Rol inválido. Asignando rol de usuario (2) por defecto.");
            rolId = 2;
        }
        
        boolean creado = usuarioService.crearUsuario(nuevoUser, email, nuevaPass, rolId);
        
        if (creado) {
            System.out.println("✅ Usuario creado correctamente.");
        } else {
            System.out.println("❌ Error al crear usuario. (Revise si el usuario o email ya existen).");
        }
    }
    
    // =================================================================
    //              LÓGICA DE GESTIÓN DE USUARIOS (RF28)
    // =================================================================
    
    public static void ejecutarMenuGestionUsuarios(Scanner sc, UsuariosService usuarioService, int idAdminLogeado) {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- ADMINISTRACIÓN DE USUARIOS (RF28) ---");
            System.out.println("1. Listar todos los Usuarios");
            System.out.println("2. Actualizar datos de Usuario (Email/Rol/Activo)");
            System.out.println("3. Eliminar Usuario");
            System.out.println("4. Volver al menú de Administrador");
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1":
                    listarUsuarios(usuarioService);
                    break;
                case "2":
                    actualizarUsuarioExistente(sc, usuarioService);
                    break;
                case "3":
                    eliminarUsuario(sc, usuarioService, idAdminLogeado);
                    break;
                case "4":
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
    
    public static void listarUsuarios(UsuariosService usuarioService) {
        System.out.println("\n--- LISTA DE USUARIOS ---");
        try {
            List<Usuarios> usuarios = usuarioService.listarUsuarios();
            if (usuarios.isEmpty()) {
                System.out.println("No hay usuarios registrados.");
                return;
            }
            
            System.out.println(String.format("%-5s | %-20s | %-25s | %-10s | %-7s", "ID", "Usuario", "Email", "Rol ID", "Activo"));
            System.out.println("-------------------------------------------------------------------------------");
            usuarios.forEach(u -> {
                System.out.println(String.format("%-5d | %-20s | %-25s | %-10d | %-7b", 
                                                u.getId(), 
                                                u.getNombreUsuario(), 
                                                u.getEmail(), 
                                                u.getRolId(),
                                                u.isActivo()));
            });
            
        } catch (Exception e) {
            System.err.println("❌ Error al listar usuarios: " + e.getMessage());
        }
    }
    
    public static void actualizarUsuarioExistente(Scanner sc, UsuariosService usuarioService) {
        System.out.println("\n--- ACTUALIZAR USUARIO ---");
        try {
            System.out.println("ID del Usuario a actualizar: ");
            int id = Integer.parseInt(sc.nextLine());
            
            Usuarios usuario = usuarioService.buscarUsuario(id);
            if (usuario == null) {
                System.err.println("❌ Error: Usuario no encontrado con ID: " + id);
                return;
            }

            System.out.println("Datos actuales: ID=" + id + ", Nombre=" + usuario.getNombreUsuario() + ", Email=" + usuario.getEmail() + ", Rol=" + usuario.getRolId() + ", Activo=" + usuario.isActivo());
            System.out.println("Introduce los NUEVOS datos (o presiona ENTER para mantener el valor actual):");
            
            System.out.println("Nuevo Nombre (Actual: " + usuario.getNombreUsuario() + "): ");
            String nombre = sc.nextLine();
            if (!nombre.trim().isEmpty()) {
                usuario.setNombreUsuario(nombre);
            }
            
            System.out.println("Nuevo Email (Actual: " + usuario.getEmail() + "): ");
            String email = sc.nextLine();
            if (!email.trim().isEmpty()) {
                usuario.setEmail(email);
            }
            
            System.out.println("Nuevo Rol (1=Admin, 2=Usuario) (Actual: " + usuario.getRolId() + "): ");
            String rolStr = sc.nextLine();
            if (!rolStr.trim().isEmpty()) {
                int rolId = Integer.parseInt(rolStr);
                if (rolId == 1 || rolId == 2) {
                    usuario.setRolId(rolId);
                } else {
                    System.out.println("⚠️ Rol inválido. Se mantiene el rol actual.");
                }
            }
            
            System.out.println("¿Activo? (true/false) (Actual: " + usuario.isActivo() + "): ");
            String activoStr = sc.nextLine();
            if (!activoStr.trim().isEmpty()) {
                usuario.setActivo(activoStr.equalsIgnoreCase("true") || activoStr.equalsIgnoreCase("t"));
            }
            
            usuarioService.actualizarUsuario(usuario);
            System.out.println("✅ Usuario actualizado correctamente.");

        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (Exception e) {
            System.err.println("❌ Error de negocio o base de datos: " + e.getMessage());
        }
    }
    
    public static void eliminarUsuario(Scanner sc, UsuariosService usuarioService, int idAdminLogeado) {
        System.out.println("\n--- ELIMINAR USUARIO ---");
        try {
            System.out.println("ID del Usuario a eliminar: ");
            int id = Integer.parseInt(sc.nextLine());
            
            usuarioService.eliminarUsuario(id, idAdminLogeado);
            System.out.println("✅ Usuario eliminado correctamente.");
            
        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (Exception e) {
            System.err.println("❌ Error al eliminar: " + e.getMessage());
        }
    }

    // =================================================================
    //              LÓGICA DE GESTIÓN DE PROVEEDORES
    // =================================================================
    
    public static void ejecutarMenuProveedores(Scanner sc, IProveedorService proveedorService) {
        boolean volver = false;
        while (!volver) {
            System.out.println("\n--- GESTIÓN DE PROVEEDORES ---");
            System.out.println("1. Crear Nuevo Proveedor");
            System.out.println("2. Listar Proveedores");
            System.out.println("3. Actualizar Proveedor");
            System.out.println("4. Eliminar Proveedor");
            System.out.println("5. Volver al menú de Administrador");
            System.out.println("Elige una opción: ");
            String opcionMenu = sc.nextLine();
            
            switch (opcionMenu) {
                case "1":
                    crearNuevoProveedor(sc, proveedorService);
                    break;
                case "2":
                    listarProveedores(proveedorService);
                    break;
                case "3":
                    actualizarProveedorExistente(sc, proveedorService);
                    break;
                case "4":
                    eliminarProveedor(sc, proveedorService);
                    break;
                case "5":
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida.");
            }
        }
    }
    
    public static void crearNuevoProveedor(Scanner sc, IProveedorService proveedorService) {
        System.out.println("\n--- CREAR NUEVO PROVEEDOR ---");
        try {
            System.out.println("Nombre del Proveedor: ");
            String nombre = sc.nextLine();
            System.out.println("RUC (Opcional, presiona ENTER para omitir): ");
            String ruc = sc.nextLine();
            System.out.println("Teléfono (Opcional): ");
            String telefono = sc.nextLine();
            System.out.println("Dirección (Opcional): ");
            String direccion = sc.nextLine();
            
            Proveedor proveedor = new Proveedor(nombre, ruc, telefono, direccion);
            proveedorService.crearProveedor(proveedor);
            
            System.out.println("✅ Proveedor '" + nombre + "' creado correctamente.");
            
        } catch (Exception e) {
            System.err.println("❌ Error al crear proveedor: " + e.getMessage());
        }
    }
    
    public static void listarProveedores(IProveedorService proveedorService) {
        System.out.println("\n--- LISTA DE PROVEEDORES ---");
        try {
            List<Proveedor> proveedores = proveedorService.listarProveedores();
            if (proveedores.isEmpty()) {
                System.out.println("No hay proveedores registrados.");
                return;
            }
            System.out.println(String.format("%-5s | %-25s | %-15s | %-15s", "ID", "Nombre", "RUC", "Teléfono"));
            System.out.println("-------------------------------------------------------------------");
            proveedores.forEach(p -> {
                 System.out.println(String.format("%-5d | %-25s | %-15s | %-15s", 
                                                 p.getId(), p.getNombre(), p.getRuc(), p.getTelefono()));
            });
            
        } catch (Exception e) {
            System.err.println("❌ Error al listar proveedores: " + e.getMessage());
        }
    }
    
    public static void actualizarProveedorExistente(Scanner sc, IProveedorService proveedorService) {
        System.out.println("\n--- ACTUALIZAR PROVEEDOR ---");
        try {
            System.out.println("ID del Proveedor a actualizar: ");
            int id = Integer.parseInt(sc.nextLine());
            
            Proveedor proveedor = proveedorService.buscarProveedor(id);
            if (proveedor == null) {
                System.err.println("❌ Error: Proveedor no encontrado con ID: " + id);
                return;
            }

            System.out.println("Introduce los NUEVOS datos (o presiona ENTER para mantener el valor actual):");
            
            System.out.println("Nuevo Nombre (Actual: " + proveedor.getNombre() + "): ");
            String nombre = sc.nextLine();
            if (!nombre.trim().isEmpty()) {
                proveedor.setNombre(nombre);
            }
            
            System.out.println("Nuevo RUC (Actual: " + proveedor.getRuc() + "): ");
            String ruc = sc.nextLine();
            if (!ruc.trim().isEmpty()) {
                proveedor.setRuc(ruc);
            }
            
            System.out.println("Nuevo Teléfono (Actual: " + proveedor.getTelefono() + "): ");
            String telefono = sc.nextLine();
            if (!telefono.trim().isEmpty()) {
                proveedor.setTelefono(telefono);
            }
            
            System.out.println("Nueva Dirección (Actual: " + proveedor.getDireccion() + "): ");
            String direccion = sc.nextLine();
            if (!direccion.trim().isEmpty()) {
                proveedor.setDireccion(direccion);
            }
            
            proveedorService.actualizarProveedor(proveedor);
            System.out.println("✅ Proveedor actualizado correctamente.");

        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (Exception e) {
            System.err.println("❌ Error de negocio o base de datos: " + e.getMessage());
        }
    }
    
    public static void eliminarProveedor(Scanner sc, IProveedorService proveedorService) {
        System.out.println("\n--- ELIMINAR PROVEEDOR ---");
        try {
            System.out.println("ID del Proveedor a eliminar: ");
            int id = Integer.parseInt(sc.nextLine());
            
            proveedorService.eliminarProveedor(id);
            System.out.println("✅ Proveedor eliminado correctamente.");
            
        } catch (NumberFormatException e) {
            System.err.println("❌ Error: Valor numérico inválido.");
        } catch (Exception e) {
            System.err.println("❌ Error al eliminar: " + e.getMessage());
        }
    }
}