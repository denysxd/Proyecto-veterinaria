package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.Producto;
import com.mycompany.nativo.modelos.Categoria;
import com.mycompany.nativo.modelos.Proveedor; 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAOJDBC implements IProductoDAO {
    
    private static final String SELECT_BASE = 
        "SELECT p.id, p.nombre, p.cantidad, p.precio, p.fecha_fabricacion, p.fecha_caducidad, p.stock_minimo, p.fecha_ultima_modificacion, p.estado, " +
        "p.categoria_id, c.nombre AS cat_nombre, " +
        "p.proveedor_id, v.nombre AS prov_nombre, v.ruc, v.telefono, v.direccion " + 
        "FROM Producto p " +
        "LEFT JOIN Categoria c ON p.categoria_id = c.id " +
        "LEFT JOIN Proveedor v ON p.proveedor_id = v.id"; 

    private Producto mapearProducto(ResultSet rs) throws SQLException {
        Categoria categoria = new Categoria();
        categoria.setId(rs.getInt("categoria_id"));
        categoria.setNombre(rs.getString("cat_nombre"));
        
        Proveedor proveedor = new Proveedor();
        proveedor.setId(rs.getInt("proveedor_id"));
        proveedor.setNombre(rs.getString("prov_nombre"));
        proveedor.setRuc(rs.getString("ruc"));
        proveedor.setTelefono(rs.getString("telefono"));
        proveedor.setDireccion(rs.getString("direccion"));

        return new Producto(
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getInt("cantidad"), 
            rs.getDouble("precio"),
            rs.getDate("fecha_fabricacion"), 
            rs.getDate("fecha_caducidad"), 
            categoria,
            proveedor,
            rs.getInt("stock_minimo"), 
            rs.getTimestamp("fecha_ultima_modificacion"),
            rs.getString("estado")
        );
    }

    @Override
    public void crear(Producto producto) throws Exception {
        String sql = "INSERT INTO Producto (nombre, cantidad, precio, fecha_fabricacion, fecha_caducidad, stock_minimo, categoria_id, proveedor_id, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getCantidad());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setDate(4, producto.getFechaFabricacion());
            stmt.setDate(5, producto.getFechaCaducidad());
            stmt.setInt(6, producto.getStockMinimo());
            stmt.setInt(7, producto.getCategoriaId()); 
            stmt.setInt(8, producto.getProveedorId()); 
            stmt.setString(9, producto.getEstado());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    producto.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public Producto obtenerPorId(int id) throws Exception {
        String sql = SELECT_BASE + " WHERE p.id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapearProducto(rs);
            }
        }
        return null;
    }

    @Override
    public List<Producto> obtenerTodos() throws Exception {
        List<Producto> productos = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_BASE)) {
            while (rs.next()) productos.add(mapearProducto(rs));
        }
        return productos;
    }

    @Override
    public void actualizar(Producto producto) throws Exception {
        String sql = "UPDATE Producto SET nombre = ?, cantidad = ?, precio = ?, fecha_fabricacion = ?, fecha_caducidad = ?, stock_minimo = ?, categoria_id = ?, proveedor_id = ?, estado = ? WHERE id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getCantidad());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setDate(4, producto.getFechaFabricacion());
            stmt.setDate(5, producto.getFechaCaducidad());
            stmt.setInt(6, producto.getStockMinimo());
            stmt.setInt(7, producto.getCategoriaId());
            stmt.setInt(8, producto.getProveedorId()); 
            stmt.setString(9, producto.getEstado());
            stmt.setInt(10, producto.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        String sql = "DELETE FROM Producto WHERE id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    @Override
    public void actualizarStock(Connection conn, int productoId, int cantidadCambio) throws Exception {
        String sql = "UPDATE Producto SET cantidad = cantidad + ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cantidadCambio); 
            stmt.setInt(2, productoId);
            stmt.executeUpdate();
        }
    }

    @Override
    public List<Producto> obtenerStockBajo(int limiteIgnorado) throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE + " WHERE p.cantidad <= p.stock_minimo";
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) productos.add(mapearProducto(rs));
        }
        return productos;
    }

    @Override
    public void agregarAlmacenAProducto(int productoId, int almacenId) throws Exception {}
    @Override
    public void eliminarAlmacenDeProducto(int productoId, int almacenId) throws Exception {}

    // --- BÚSQUEDAS Y FILTROS ---
    @Override
    public List<Producto> buscarPorNombre(String termino) throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE + " WHERE p.nombre LIKE ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + termino + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }

    @Override
    public List<Producto> obtenerPorVencer(int dias) throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE + " WHERE p.estado = 'Activo' AND p.fecha_caducidad BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, dias);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }
    
    @Override
    public Producto obtenerPorNombre(String nombreExacto) throws Exception {
        String sql = SELECT_BASE + " WHERE p.nombre = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nombreExacto);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return mapearProducto(rs);
            }
        }
        return null;
    }

    @Override
    public List<Producto> obtenerPorProveedor(int proveedorId) throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE + " WHERE p.proveedor_id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, proveedorId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }
    
    @Override
    public List<Producto> obtenerPorCategoria(int categoriaId) throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE + " WHERE p.categoria_id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, categoriaId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }
    
    @Override
    public int actualizarEstadoVencidos() throws Exception {
        String sql = "UPDATE Producto SET estado = 'Vencido' WHERE fecha_caducidad < CURDATE() AND estado = 'Activo'";
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement()) {
            return stmt.executeUpdate(sql);
        }
    }

    // --- IMPLEMENTACIÓN RF38: BÚSQUEDA DINÁMICA ---
    @Override
    public List<Producto> buscarAvanzado(String nombre, int categoriaId, int proveedorId, boolean soloStockBajo) throws Exception {
        List<Producto> productos = new ArrayList<>();
        StringBuilder sql = new StringBuilder(SELECT_BASE + " WHERE 1=1");
        List<Object> params = new ArrayList<>();

        if (nombre != null && !nombre.trim().isEmpty()) {
            sql.append(" AND p.nombre LIKE ?");
            params.add("%" + nombre + "%");
        }
        if (categoriaId > 0) {
            sql.append(" AND p.categoria_id = ?");
            params.add(categoriaId);
        }
        if (proveedorId > 0) {
            sql.append(" AND p.proveedor_id = ?");
            params.add(proveedorId);
        }
        if (soloStockBajo) {
            sql.append(" AND p.cantidad <= p.stock_minimo");
        }

        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            // Asignar parámetros dinámicamente
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    productos.add(mapearProducto(rs));
                }
            }
        }
        return productos;
    }
}