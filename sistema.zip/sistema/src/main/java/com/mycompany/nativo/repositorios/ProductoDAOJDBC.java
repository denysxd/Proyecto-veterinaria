package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.Producto;
import com.mycompany.nativo.modelos.Categoria;
import com.mycompany.nativo.modelos.Proveedor; 
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAOJDBC implements IProductoDAO {
    
   
    private static final String SELECT_BASE = 
        "SELECT p.id, p.nombre, p.cantidad, p.precio, p.fecha_fabricacion, p.fecha_caducidad, " +
        "p.categoria_id, c.nombre AS cat_nombre, " +
        "p.proveedor_id, v.nombre AS prov_nombre, v.ruc, v.telefono, v.direccion " + 
        "FROM Producto p " +
        "LEFT JOIN Categoria c ON p.categoria_id = c.id " +
        "LEFT JOIN Proveedor v ON p.proveedor_id = v.id"; 

  
    private Producto mapearProducto(ResultSet rs) throws SQLException {
        
      
        Categoria categoria = new Categoria();
        categoria.setId(rs.getInt("categoria_id"));
        categoria.setNombre(rs.getString("cat_nombre"));
        
    
        Proveedor proveedor = new Proveedor();
        proveedor.setId(rs.getInt("proveedor_id"));
        proveedor.setNombre(rs.getString("prov_nombre"));
        proveedor.setRuc(rs.getString("ruc"));
        proveedor.setTelefono(rs.getString("telefono"));
        proveedor.setDireccion(rs.getString("direccion"));

        
        Producto producto = new Producto(
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getInt("cantidad"), 
            rs.getDouble("precio"),
            rs.getDate("fecha_fabricacion"), 
            rs.getDate("fecha_caducidad"), 
            categoria,
            proveedor 
        );
        return producto;
    }


    @Override
    public void crear(Producto producto) throws Exception {
        String sql = "INSERT INTO Producto (nombre, cantidad, precio, fecha_fabricacion, fecha_caducidad, categoria_id, proveedor_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getCantidad());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setDate(4, producto.getFechaFabricacion());
            stmt.setDate(5, producto.getFechaCaducidad());
            stmt.setInt(6, producto.getCategoriaId()); 
            stmt.setInt(7, producto.getProveedorId()); 
        
            stmt.executeUpdate();
            
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    producto.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public Producto obtenerPorId(int id) throws Exception {
        String sql = SELECT_BASE + " WHERE p.id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapearProducto(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Producto> obtenerTodos() throws Exception {
        List<Producto> productos = new ArrayList<>();
        String sql = SELECT_BASE;
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                productos.add(mapearProducto(rs));
            }
        }
        return productos;
    }

   
    @Override
    public void actualizar(Producto producto) throws Exception {
        String sql = "UPDATE Producto SET nombre = ?, cantidad = ?, precio = ?, fecha_fabricacion = ?, fecha_caducidad = ?, categoria_id = ?, proveedor_id = ? WHERE id = ?";
        
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            
            stmt.setString(1, producto.getNombre());
            stmt.setInt(2, producto.getCantidad());
            stmt.setDouble(3, producto.getPrecio());
            stmt.setDate(4, producto.getFechaFabricacion());
            stmt.setDate(5, producto.getFechaCaducidad());
            stmt.setInt(6, producto.getCategoriaId());
            stmt.setInt(7, producto.getProveedorId()); 
            stmt.setInt(8, producto.getId());
            
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        String sql = "DELETE FROM Producto WHERE id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    

    @Override
    public void actualizarStock(Connection conn, int productoId, int cantidadCambio) throws Exception {
        String sql = "UPDATE Producto SET cantidad = cantidad + ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, cantidadCambio); 
            stmt.setInt(2, productoId);
            stmt.executeUpdate();
        }
    }

    // --- Métodos de la Relación (Asumiendo que tenías una tabla producto_almacen) ---
    // (Estos métodos parecen ser de un diseño M:N anterior, los mantengo por si acaso)
    @Override
    public void agregarAlmacenAProducto(int productoId, int almacenId) throws Exception {
        // Esta lógica asume una tabla 'producto_almacen'
        String sql = "INSERT INTO producto_almacen (producto_id, almacen_id) VALUES (?, ?)";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productoId);
            stmt.setInt(2, almacenId);
            stmt.executeUpdate();
        } catch (SQLException e) {
             if (!e.getMessage().contains("Duplicate entry")) {
                 throw new Exception("Error al agregar almacén a producto", e);
             }
        }
    }

    @Override
    public void eliminarAlmacenDeProducto(int productoId, int almacenId) throws Exception {
         // Esta lógica asume una tabla 'producto_almacen'
        String sql = "DELETE FROM producto_almacen WHERE producto_id = ? AND almacen_id = ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, productoId);
            stmt.setInt(2, almacenId);
            stmt.executeUpdate();
        }
    }
}