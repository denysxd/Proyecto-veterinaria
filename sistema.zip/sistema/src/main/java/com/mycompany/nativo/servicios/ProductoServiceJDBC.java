package com.mycompany.nativo.servicios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.repositorios.ProductoDAOJDBC;
import com.mycompany.nativo.repositorios.IProductoDAO;
import com.mycompany.nativo.repositorios.AlmacenDAOJDBC;
import com.mycompany.nativo.repositorios.IAlmacenDAO;
import com.mycompany.nativo.modelos.Almacen;
import com.mycompany.nativo.modelos.Producto;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ProductoServiceJDBC implements IProductoService {
    
    private IProductoDAO productoDAO;
    private IAlmacenDAO almacenDAO; 

    public ProductoServiceJDBC() {
        this.productoDAO = new ProductoDAOJDBC();
        this.almacenDAO = new AlmacenDAOJDBC(); 
    }

    @Override
    public void crearProducto(Producto producto) throws Exception {
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del producto es obligatorio");
        }

        Producto productoExistente = productoDAO.obtenerPorNombre(producto.getNombre());

        if (productoExistente != null) {
            int nuevoTotal = productoExistente.getCantidad() + producto.getCantidad();
            System.out.println("ℹ️ El producto ya existe. Sumando stock. Nuevo total: " + nuevoTotal);
            productoExistente.setCantidad(nuevoTotal);
            productoDAO.actualizar(productoExistente);
        } else {
            if (producto.getPrecio() <= 0) throw new Exception("Precio debe ser mayor a 0");
            if (producto.getCategoriaId() <= 0 && (producto.getCategoria() == null)) {
                throw new Exception("Categoría inválida");
            }
            if (producto.getStockMinimo() < 0) throw new Exception("Stock mínimo negativo no permitido");
            
            productoDAO.crear(producto);
            System.out.println("✅ Producto creado exitosamente.");
        }
    }
    
    @Override
    public void registrarMovimientoInventario(Almacen registro, boolean esIngreso) throws Exception {
        if (registro.getProducto() == null || registro.getProducto().getId() <= 0) throw new Exception("Producto obligatorio.");
        if (registro.getUsuario() == null) throw new Exception("Usuario obligatorio.");
        if (registro.getCantidadEnAlmacen() <= 0) throw new Exception("Cantidad debe ser > 0.");

        int delta = esIngreso ? registro.getCantidadEnAlmacen() : -registro.getCantidadEnAlmacen(); 
        Connection conn = null;
        try {
            conn = Config.getConnection();
            conn.setAutoCommit(false); 

            Producto p = productoDAO.obtenerPorId(registro.getProducto().getId());
            if (p == null) throw new Exception("Producto no existe.");
            
            if (!esIngreso && "Vencido".equalsIgnoreCase(p.getEstado())) {
                throw new Exception("⛔ ERROR: No se puede vender este producto porque está VENCIDO.");
            }
            
            if (!esIngreso && p.getCantidad() < registro.getCantidadEnAlmacen()) {
                throw new Exception("Stock insuficiente.");
            }

            registro.setCantidadEnAlmacen(delta); 
            almacenDAO.crearConConexion(conn, registro);
            productoDAO.actualizarStock(conn, registro.getProducto().getId(), delta); 
            conn.commit(); 
        } catch (SQLException e) {
            if (conn != null) conn.rollback(); 
            throw new Exception("Error transacción: " + e.getMessage(), e);
        } finally {
            if (conn != null) { conn.setAutoCommit(true); conn.close(); }
        }
    }

    @Override
    public Producto buscarProducto(int id) throws Exception {
        if (id <= 0) throw new Exception("ID inválido");
        return productoDAO.obtenerPorId(id);
    }

    @Override
    public List<Producto> listarProductos() throws Exception {
        return productoDAO.obtenerTodos();
    }

    @Override
    public void actualizarProducto(Producto producto) throws Exception {
        if (producto.getId() <= 0) throw new Exception("ID inválido");
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) throw new Exception("Nombre obligatorio");
        if (producto.getStockMinimo() < 0) throw new Exception("Stock mínimo negativo no permitido");
        productoDAO.actualizar(producto);
    }

    @Override
    public void eliminarProducto(int id) throws Exception {
        if (id <= 0) throw new Exception("ID inválido");
        productoDAO.eliminar(id);
    }

    @Override
    public void asociarAlmacenAProducto(int pid, int aid) throws Exception {
        productoDAO.agregarAlmacenAProducto(pid, aid);
    }

    @Override
    public void desasociarAlmacenDeProducto(int pid, int aid) throws Exception {
        productoDAO.eliminarAlmacenDeProducto(pid, aid);
    }

    @Override
    public List<Producto> buscarProductos(String termino) throws Exception {
        return productoDAO.buscarPorNombre(termino);
    }

    @Override
    public List<Producto> obtenerAlertasVencimiento() throws Exception {
        return productoDAO.obtenerPorVencer(30); 
    }

    @Override
    public List<Producto> obtenerAlertasStock() throws Exception {
        return productoDAO.obtenerStockBajo(0); 
    }
    
    @Override
    public List<Producto> listarProductosPorProveedor(int proveedorId) throws Exception {
        if (proveedorId <= 0) throw new Exception("ID proveedor inválido");
        return productoDAO.obtenerPorProveedor(proveedorId);
    }
    
    @Override
    public List<Producto> listarProductosPorCategoria(int categoriaId) throws Exception {
        if (categoriaId <= 0) throw new Exception("ID categoría inválido");
        return productoDAO.obtenerPorCategoria(categoriaId);
    }
    
    @Override
    public int procesarVencimientos() throws Exception {
        return productoDAO.actualizarEstadoVencidos();
    }

    // --- IMPLEMENTACIÓN RF38 ---
    @Override
    public List<Producto> buscarProductosAvanzado(String nombre, int categoriaId, int proveedorId, boolean soloStockBajo) throws Exception {
        return productoDAO.buscarAvanzado(nombre, categoriaId, proveedorId, soloStockBajo);
    }
}