package com.mycompany.nativo.servicios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.repositorios.ProductoDAOJDBC;
import com.mycompany.nativo.repositorios.IProductoDAO;
import com.mycompany.nativo.repositorios.AlmacenDAOJDBC;
import com.mycompany.nativo.repositorios.IAlmacenDAO;
import com.mycompany.nativo.modelos.Almacen;
import com.mycompany.nativo.modelos.Producto;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class ProductoServiceJDBC implements IProductoService {
    
    private IProductoDAO productoDAO;
    private IAlmacenDAO almacenDAO; 

    public ProductoServiceJDBC() {
        this.productoDAO = new ProductoDAOJDBC();
        this.almacenDAO = new AlmacenDAOJDBC(); 
    }

  
    @Override
    public void crearProducto(Producto producto) throws Exception {
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del producto es obligatorio");
        }
        if (producto.getPrecio() <= 0) {
            throw new Exception("El precio debe ser mayor a 0");
        }
        if (producto.getCategoria() == null || producto.getCategoria().getId() <= 0) {
            throw new Exception("Debe seleccionar una categoría válida");
        }
        productoDAO.crear(producto);
    }
    

    @Override
    public void registrarMovimientoInventario(Almacen registro, boolean esIngreso) throws Exception {
        
  
        if (registro.getProducto() == null || registro.getProducto().getId() <= 0) {
            throw new Exception("El ID del producto es obligatorio.");
        }
        if (registro.getUsuario() == null || registro.getUsuario().getId() <= 0) {
            throw new Exception("El usuario responsable es obligatorio.");
        }
        
        int cantidadMovimiento = registro.getCantidadEnAlmacen();

        if (cantidadMovimiento <= 0) {
            throw new Exception("La cantidad del movimiento debe ser mayor a cero.");
        }

  
        int deltaMovimiento = esIngreso ? cantidadMovimiento : -cantidadMovimiento; 

        Connection conn = null;
        try {
            conn = Config.getConnection();
            conn.setAutoCommit(false); 

         
            Producto productoActual = productoDAO.obtenerPorId(registro.getProducto().getId());
            if (productoActual == null) {
                 throw new Exception("El producto con ID " + registro.getProducto().getId() + " no existe.");
            }
            
          
            if (!esIngreso && productoActual.getCantidad() < cantidadMovimiento) {
                throw new Exception("No hay stock suficiente. Stock actual: " + productoActual.getCantidad());
            }

        
            registro.setCantidadEnAlmacen(deltaMovimiento); 

          
            almacenDAO.crearConConexion(conn, registro);

         
            productoDAO.actualizarStock(conn, registro.getProducto().getId(), deltaMovimiento); 
            
            conn.commit(); 
            
        } catch (SQLException e) {
            if (conn != null) { 
                conn.rollback(); 
            }
            throw new Exception("Error en la transacción de inventario: " + e.getMessage(), e);
        } finally {
            if (conn != null) {
                conn.setAutoCommit(true);
                conn.close();
            }
        }
    }
    
 

    @Override
    public Producto buscarProducto(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID inválido");
        }
        return productoDAO.obtenerPorId(id);
    }

    @Override
    public List<Producto> listarProductos() throws Exception {
        return productoDAO.obtenerTodos();
    }

    @Override
    public void actualizarProducto(Producto producto) throws Exception {
         if (producto.getId() <= 0) {
            throw new Exception("ID inválido");
        }
        if (producto.getNombre() == null || producto.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del producto es obligatorio");
        }
        if (producto.getCategoriaId() <= 0 && (producto.getCategoria() == null || producto.getCategoria().getId() <= 0)) {
            throw new Exception("Debe seleccionar una categoría válida");
        }
        productoDAO.actualizar(producto);
    }

    @Override
    public void eliminarProducto(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID inválido");
        }
        productoDAO.eliminar(id);
    }

    @Override
    public void asociarAlmacenAProducto(int productoId, int almacenId) throws Exception {
        if (productoId <= 0 || almacenId <= 0) {
            throw new Exception("IDs de producto/almacén inválidos");
        }
        productoDAO.agregarAlmacenAProducto(productoId, almacenId);
    }

    @Override
    public void desasociarAlmacenDeProducto(int productoId, int almacenId) throws Exception {
         if (productoId <= 0 || almacenId <= 0) {
            throw new Exception("IDs de producto/almacén inválidos");
        }
        productoDAO.eliminarAlmacenDeProducto(productoId, almacenId);
    }
}