package com.mycompany.nativo.servicios;

import com.mycompany.nativo.repositorios.UsuariosDao; 
import com.mycompany.nativo.repositorios.UsuariosDaoJDBC;
import com.mycompany.nativo.modelos.Usuarios;
import java.sql.SQLException;
import java.util.List;

public class UsuariosService {
    
    private final UsuariosDao usuarioDao;

    public UsuariosService() {
        this.usuarioDao = new UsuariosDaoJDBC(); 
    }

 
    public Usuarios login(String email, String contrasenaPlana) {
        Usuarios usuario = null;
        try {
            usuario = usuarioDao.obtenerUsuarioPorEmail(email); 
            
            if (usuario == null || !usuario.isActivo()) { 
                return null; 
            }
            
            if (contrasenaPlana.equals(usuario.getContrasena())) {
                return usuario; 
            } else {
                return null; 
            }
            
        } catch (SQLException e) {
            System.err.println("Error de Base de Datos en el login: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
    

    public boolean crearUsuario(String nombreUsuario, String email, String contrasenaPlana, int rolId) {
        try {
            Usuarios existeUsuarioEmail = usuarioDao.obtenerUsuarioPorEmail(email);
            if (existeUsuarioEmail != null) {
                System.err.println("Error: El email '" + email + "' ya está registrado.");
                return false;
            }

            Usuarios existeUsuarioNombre = usuarioDao.obtenerUsuarioPorNombre(nombreUsuario);
            if (existeUsuarioNombre != null) {
                System.out.println("El nombre de usuario '" + nombreUsuario + "' ya está registrado.");
                return false;
            }

            Usuarios nuevoUsuario = new Usuarios(nombreUsuario, email, contrasenaPlana, rolId);

            int resultado = usuarioDao.insertar(nuevoUsuario);

            return resultado == 1; 
            
        } catch (SQLException e) {
            System.err.println("Error de Base de Datos al crear usuario: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    

 
    public List<Usuarios> listarUsuarios() throws Exception {
       
        return usuarioDao.obtenerTodos();
    }
    
   
    public Usuarios buscarUsuario(int id) throws Exception {
     
        if (id <= 0) {
            throw new Exception("ID de usuario inválido.");
        }
        return usuarioDao.obtenerUsuarioPorId(id);
    }

   
    public void actualizarUsuario(Usuarios usuario) throws Exception {
     
        if (usuario.getId() <= 0) {
            throw new Exception("ID de usuario inválido.");
        }
        if (usuario.getNombreUsuario() == null || usuario.getNombreUsuario().trim().isEmpty()) {
            throw new Exception("El nombre de usuario es obligatorio.");
        }
        if (usuario.getEmail() == null || usuario.getEmail().trim().isEmpty()) {
            throw new Exception("El email es obligatorio.");
        }
        
        try {
            usuarioDao.actualizar(usuario);
        } catch (SQLException e) {
            if (e.getMessage().contains("Duplicate entry") && e.getMessage().contains("email")) {
                throw new Exception("Error: El email '" + usuario.getEmail() + "' ya pertenece a otro usuario.");
            }
            throw new Exception("Error de BD al actualizar usuario: " + e.getMessage());
        }
    }
    
   
    public void eliminarUsuario(int id, int idAdminLogeado) throws Exception {
    
        if (id <= 0) {
            throw new Exception("ID de usuario inválido.");
        }
        if (id == idAdminLogeado) {
            throw new Exception("No puede eliminarse a sí mismo.");
        }
        usuarioDao.eliminar(id);
    }
}