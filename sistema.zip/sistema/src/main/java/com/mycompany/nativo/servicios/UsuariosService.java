package com.mycompany.nativo.servicios;

import com.mycompany.nativo.repositorios.*; 
import com.mycompany.nativo.modelos.*;
import java.sql.SQLException;
import java.util.List;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;
import java.net.InetAddress;
import java.util.UUID; 

public class UsuariosService {
    
    private final UsuariosDao usuarioDao;
    private final IHistorialLoginDAO historialDao;
    private final IRecuperacionDAO recuperacionDao; 
    private final CorreoService correoService; 
    private final SmsService smsService; // <-- SMS SERVICE

    public UsuariosService() {
        this.usuarioDao = new UsuariosDaoJDBC(); 
        this.historialDao = new HistorialLoginDAOJDBC();
        this.recuperacionDao = new RecuperacionDAOJDBC();
        this.correoService = new CorreoService();
        this.smsService = new SmsService(); // <-- INICIALIZAR SMS
    }

    // --- HASHING ---
    private String hashearPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return String.format("%064x", new BigInteger(1, encodedhash));
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public Usuarios login(String email, String contrasenaPlana) {
        try {
            Usuarios usuario = usuarioDao.obtenerUsuarioPorEmail(email); 
            if (usuario == null || !usuario.isActivo()) return null; 
            
            // CLAVE: Comparamos el HASH del input con el HASH guardado
            if (hashearPassword(contrasenaPlana).equals(usuario.getContrasena())) {
                try { historialDao.registrarLogin(usuario.getId(), InetAddress.getLocalHost().getHostAddress()); } catch(Exception e) {}
                return usuario; 
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
    
    // --- RF30: RECUPERACIÓN POR EMAIL ---
    public boolean iniciarRecuperacion(String email) {
        try {
            Usuarios u = usuarioDao.obtenerUsuarioPorEmail(email);
            if (u == null) {
                System.out.println("❌ Ese correo no está registrado.");
                return false;
            }
            String token = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
            recuperacionDao.guardarToken(u.getId(), token);
            
            boolean enviado = correoService.enviarCorreoRecuperacion(email, token);
            if(enviado) {
                System.out.println("✅ Se envió un código a " + email);
                return true;
            }
            return false;
        } catch(Exception e) { e.printStackTrace(); return false; }
    }

    // --- RF30: RECUPERACIÓN POR SMS ---
    public boolean iniciarRecuperacionSMS(String telefono) {
        try {
            // 1. Buscamos si el usuario existe por su teléfono
            Usuarios u = usuarioDao.obtenerUsuarioPorTelefono(telefono);
            
            if (u == null) {
                System.out.println("❌ Ese número de teléfono no está registrado en el sistema.");
                return false;
            }
            
            String token = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
            recuperacionDao.guardarToken(u.getId(), token);
            
            // 2. Enviamos SMS usando Twilio
            return smsService.enviarSmsRecuperacion(telefono, token);
            
        } catch(Exception e) { 
            e.printStackTrace(); 
            return false; 
        }
    }
    
    // --- RF30: CAMBIAR CLAVE CON TOKEN ---
    public boolean cambiarClaveConToken(String token, String nuevaPass) {
        try {
            int userId = recuperacionDao.validarToken(token);
            if (userId == 0) return false;
            
            Usuarios u = usuarioDao.obtenerUsuarioPorId(userId);
            u.setContrasena(hashearPassword(nuevaPass)); 
            usuarioDao.actualizarContrasena(u); // <-- Llama al método dedicado
            recuperacionDao.eliminarToken(token); 
            return true;
        } catch(Exception e) { e.printStackTrace(); return false; }
    }

    // --- CREAR USUARIO (AHORA RECIBE TELÉFONO) ---
    public boolean crearUsuario(String u, String e, String p, int r, String t) {
        try {
            if(usuarioDao.obtenerUsuarioPorEmail(e)!=null) return false;
            // Pasamos el teléfono 't' al insertar
            return usuarioDao.insertar(new Usuarios(u,e,hashearPassword(p),r, t)) == 1; 
        } catch(Exception ex) { return false; }
    }
    
    public List<Usuarios> listarUsuarios() throws Exception { return usuarioDao.obtenerTodos(); }
    public List<HistorialLogin> obtenerReporteAuditoria() throws Exception { return historialDao.obtenerTodos(); }
    public void eliminarUsuario(int id, int adminId) throws Exception { usuarioDao.eliminar(id); }
}