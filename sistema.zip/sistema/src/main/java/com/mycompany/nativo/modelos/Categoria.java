package com.mycompany.nativo.modelos;

public class Categoria {

    private int id; // Por defecto es 0 si no se asigna
    private String nombre;

    // Constructor para INSERTAR (usado al crear)
    public Categoria(String nombre) {
        this.nombre = nombre;
    }

    // Constructor vacío (necesario para el mapeo)
    public Categoria() {
    }
    
    // 🔄 CONSTRUCTOR AÑADIDO (Para LEER de la BD)
    public Categoria(int id, String nombre) {
        this.id = id;
        this.nombre = nombre;
    }

    // --- Getters y Setters ---

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        // Aseguramos que el toString muestre ambos campos
        return "Categoria{" + "id=" + id + ", nombre=" + nombre + '}';
    }
}