/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.nativo.servicios;

import com.mycompany.nativo.modelos.Proveedor;
import com.mycompany.nativo.repositorios.IProveedorDAO;
import com.mycompany.nativo.repositorios.ProveedorDAOJDBC;
import java.util.List;

public class ProveedorServiceJDBC implements IProveedorService {
    
    private IProveedorDAO proveedorDAO;
 

    public ProveedorServiceJDBC() {
        this.proveedorDAO = new ProveedorDAOJDBC();
       
    }

    @Override
    public void crearProveedor(Proveedor proveedor) throws Exception {
      
        if (proveedor.getNombre() == null || proveedor.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del proveedor es obligatorio.");
        }
      
        proveedorDAO.crear(proveedor);
    }

    @Override
    public Proveedor buscarProveedor(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        return proveedorDAO.obtenerPorId(id);
    }

    @Override
    public List<Proveedor> listarProveedores() throws Exception {
        return proveedorDAO.obtenerTodos();
    }

    @Override
    public void actualizarProveedor(Proveedor proveedor) throws Exception {
        if (proveedor.getId() <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        if (proveedor.getNombre() == null || proveedor.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del proveedor es obligatorio.");
        }
        proveedorDAO.actualizar(proveedor);
    }

    @Override
    public void eliminarProveedor(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        

        
        proveedorDAO.eliminar(id);
    }
}