package com.mycompany.nativo.servicios;

import com.mycompany.nativo.modelos.Proveedor;
import com.mycompany.nativo.modelos.Producto; // Importamos Producto
import com.mycompany.nativo.repositorios.IProveedorDAO;
import com.mycompany.nativo.repositorios.ProveedorDAOJDBC;
import com.mycompany.nativo.repositorios.IProductoDAO; // Importamos interfaz Producto
import com.mycompany.nativo.repositorios.ProductoDAOJDBC; // Importamos implementación Producto
import java.util.List;

public class ProveedorServiceJDBC implements IProveedorService {
    
    private IProveedorDAO proveedorDAO;
    private IProductoDAO productoDAO; // <--- Variable nueva para consultar productos

    public ProveedorServiceJDBC() {
        this.proveedorDAO = new ProveedorDAOJDBC();
        this.productoDAO = new ProductoDAOJDBC(); // <--- Inicializamos el DAO de productos
    }

    @Override
    public void crearProveedor(Proveedor proveedor) throws Exception {
        if (proveedor.getNombre() == null || proveedor.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del proveedor es obligatorio.");
        }
        proveedorDAO.crear(proveedor);
    }

    @Override
    public Proveedor buscarProveedor(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        return proveedorDAO.obtenerPorId(id);
    }

    @Override
    public List<Proveedor> listarProveedores() throws Exception {
        return proveedorDAO.obtenerTodos();
    }

    @Override
    public void actualizarProveedor(Proveedor proveedor) throws Exception {
        if (proveedor.getId() <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        if (proveedor.getNombre() == null || proveedor.getNombre().trim().isEmpty()) {
            throw new Exception("El nombre del proveedor es obligatorio.");
        }
        proveedorDAO.actualizar(proveedor);
    }

    @Override
    public void eliminarProveedor(int id) throws Exception {
        if (id <= 0) {
            throw new Exception("ID de proveedor inválido.");
        }
        
        // --- IMPLEMENTACIÓN RF15 (VALIDACIÓN DE INTEGRIDAD) ---
        // 1. Buscamos si hay productos ligados a este proveedor
        List<Producto> productosDelProveedor = productoDAO.obtenerPorProveedor(id);
        
        // 2. Si la lista NO está vacía, significa que tiene productos activos.
        if (!productosDelProveedor.isEmpty()) {
            throw new Exception("⛔ ACCIÓN DENEGADA: No se puede eliminar el proveedor porque suministra " + 
                                productosDelProveedor.size() + " productos activos. " +
                                "Elimine o reasigne esos productos primero.");
        }
        
        // 3. Si no tiene productos, procedemos a eliminar
        proveedorDAO.eliminar(id);
    }
    
    @Override
    public List<Proveedor> buscarProveedores(String termino) throws Exception {
        return proveedorDAO.buscarPorNombre(termino);
    }
}