package com.mycompany.nativo.servicios;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SmsService {

    // --- TUS CREDENCIALES DE TWILIO ---
    public static final String ACCOUNT_SID = "ACf721b2f103589cf8b73a235de21d2006"; // <--- YA PUESTO (De tu imagen)
    public static final String AUTH_TOKEN = "89c4ddde1560abeebc15f1355064f5fa";      // <--- ¡FALTA ESTE! (Cópialo de Twilio)
    public static final String TWILIO_NUMBER = "+1 980 370 4964";                 // <--- ¡FALTA ESTE! (Tu número de Twilio)

    public SmsService() {
        try {
            Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        } catch (Exception e) {
            System.err.println("❌ Error inicializando Twilio: " + e.getMessage());
        }
    }

    public boolean enviarSmsRecuperacion(String numeroDestino, String token) {
        try {
            System.out.println("📡 Enviando SMS a " + numeroDestino + "...");
            
            Message message = Message.creator(
                    new PhoneNumber(numeroDestino),
                    new PhoneNumber(TWILIO_NUMBER),
                    "\n[VETERINARIA]\nTu código de recuperación es: " + token
            ).create();

            System.out.println("✅ SMS enviado con éxito! SID: " + message.getSid());
            return true;
            
        } catch (com.twilio.exception.ApiException e) {
            if(e.getCode() == 21608) {
                System.out.println("❌ ERROR: El número " + numeroDestino + " no está verificado en tu cuenta de prueba de Twilio.");
            } else {
                System.err.println("❌ Error de Twilio: " + e.getMessage());
            }
            return false;
        } catch (Exception e) {
            System.err.println("❌ Error general SMS: " + e.getMessage());
            return false;
        }
    }
}