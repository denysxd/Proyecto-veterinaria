package com.mycompany.nativo.modelos; 

import java.sql.Date; 
import com.mycompany.nativo.modelos.Producto; 
import com.mycompany.nativo.modelos.Usuarios; 

public class Almacen {
    
    private int id; 
    private Producto producto; 
    private int cantidadEnAlmacen;
    private Date fechaEntrada;
    private Usuarios usuario;
    

    public Almacen(Producto producto, int cantidadEnAlmacen, Usuarios usuario) {
        this.producto = producto;
        this.cantidadEnAlmacen = cantidadEnAlmacen;
        this.usuario = usuario;
    }
    

    public Almacen(int id, Producto producto, int cantidadEnAlmacen, Date fechaEntrada, Usuarios usuario) {
        this.id = id;
        this.producto = producto;
        this.cantidadEnAlmacen = cantidadEnAlmacen;
        this.fechaEntrada = fechaEntrada;
        this.usuario = usuario;
    }

 
    public Almacen() {}



    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public int getCantidadEnAlmacen() {
        return cantidadEnAlmacen;
    }

    public void setCantidadEnAlmacen(int cantidadEnAlmacen) {
        this.cantidadEnAlmacen = cantidadEnAlmacen;
    }

    public Date getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(Date fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }
    

    @Override
    public String toString() {
        return "RegistroAlmacen{" +
                "id=" + id +
                ", productoId=" + (producto != null ? producto.getId() : "N/A") +
                ", cantidad=" + cantidadEnAlmacen +
                ", fecha='" + fechaEntrada + '\'' +
                ", usuarioId=" + (usuario != null ? usuario.getId() : "N/A") +
                '}';
    }
}