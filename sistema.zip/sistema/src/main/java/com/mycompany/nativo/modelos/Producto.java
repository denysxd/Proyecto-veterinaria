package com.mycompany.nativo.modelos;

import java.util.ArrayList;
import java.util.List;
import java.sql.Date; 
import java.sql.Timestamp; 

public class Producto {

    private int id;
    private String nombre;
    private int cantidad; 
    private double precio;
    private Date fechaFabricacion; 
    private Date fechaCaducidad;   
    
    private int stockMinimo; 
    private Timestamp fechaUltimaModificacion; 
    private String estado; // <--- NUEVO CAMPO RF34

    private Categoria categoria;
    private Proveedor proveedor; 
    private List<Almacen> almacenes; 

    private int categoriaId; 
    private int proveedorId; 

    public Producto() {
        this.almacenes = new ArrayList<>();
        this.estado = "Activo"; // Valor por defecto
    }

    // Constructor para LEER DE LA BD (con todos los campos)
    public Producto(int id, String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, Categoria categoria, Proveedor proveedor, int stockMinimo, Timestamp fechaUltimaModificacion, String estado) {
        this.id = id;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.fechaFabricacion = fechaFabricacion;
        this.fechaCaducidad = fechaCaducidad;
        this.categoria = categoria;
        this.proveedor = proveedor;
        this.stockMinimo = stockMinimo;
        this.fechaUltimaModificacion = fechaUltimaModificacion;
        this.estado = estado; // <--- RF34
        
        if (categoria != null) this.categoriaId = categoria.getId();
        if (proveedor != null) this.proveedorId = proveedor.getId();
    }
    
    // Constructor para CREAR (Usado en Main)
    public Producto(String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, Categoria categoria, Proveedor proveedor, int stockMinimo) {
        this();
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.fechaFabricacion = fechaFabricacion;
        this.fechaCaducidad = fechaCaducidad;
        this.categoria = categoria;
        this.proveedor = proveedor;
        this.stockMinimo = stockMinimo;
        this.estado = "Activo"; // Por defecto al crear
        
        if (categoria != null) this.categoriaId = categoria.getId();
        if (proveedor != null) this.proveedorId = proveedor.getId();
    }
    
    // Constructor básico (compatibilidad)
    public Producto(int id, String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, Categoria categoria, Proveedor proveedor) {
        this(id, nombre, cantidad, precio, fechaFabricacion, fechaCaducidad, categoria, proveedor, 0, null, "Activo");
    }

    // --- Getters y Setters ---
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    public Date getFechaFabricacion() { return fechaFabricacion; }
    public void setFechaFabricacion(Date fechaFabricacion) { this.fechaFabricacion = fechaFabricacion; }
    public Date getFechaCaducidad() { return fechaCaducidad; }
    public void setFechaCaducidad(Date fechaCaducidad) { this.fechaCaducidad = fechaCaducidad; }
    
    public int getStockMinimo() { return stockMinimo; }
    public void setStockMinimo(int stockMinimo) { this.stockMinimo = stockMinimo; }

    public Timestamp getFechaUltimaModificacion() { return fechaUltimaModificacion; }
    public void setFechaUltimaModificacion(Timestamp fechaUltimaModificacion) { this.fechaUltimaModificacion = fechaUltimaModificacion; }
    
    // --- GETTER/SETTER ESTADO (RF34) ---
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    // -----------------------------------

    public Categoria getCategoria() { return categoria; }
    public void setCategoria(Categoria categoria) { this.categoria = categoria; }
    public Proveedor getProveedor() { return proveedor; }
    public void setProveedor(Proveedor proveedor) { this.proveedor = proveedor; }
    public List<Almacen> getAlmacenes() { return almacenes; }
    public void setAlmacenes(List<Almacen> almacenes) { this.almacenes = almacenes; }
    public int getCategoriaId() { return categoriaId; }
    public void setCategoriaId(int categoriaId) { this.categoriaId = categoriaId; }
    public int getProveedorId() { return proveedorId; }
    public void setProveedorId(int proveedorId) { this.proveedorId = proveedorId; }
    
    @Override
    public String toString() {
        return "Producto{" + "id=" + id + ", nombre=" + nombre + ", estado=" + estado + "}";
    }
}