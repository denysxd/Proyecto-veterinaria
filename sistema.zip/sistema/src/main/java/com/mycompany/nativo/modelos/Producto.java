package com.mycompany.nativo.modelos;

import java.util.ArrayList;
import java.util.List;
import java.sql.Date; 

public class Producto {

    private int id;
    private String nombre;
    private int cantidad; 
    private double precio;
    private Date fechaFabricacion; 
    private Date fechaCaducidad;   
    

    private Categoria categoria;
    private Proveedor proveedor; 
    private List<Almacen> almacenes; 

 
    private int categoriaId; 
    private int proveedorId; 

 
    
    public Producto() {
        this.almacenes = new ArrayList<>();
    }

  
    public Producto(String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, int categoriaId, int proveedorId) {
        this();
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.fechaFabricacion = fechaFabricacion;
        this.fechaCaducidad = fechaCaducidad;
        this.categoriaId = categoriaId;
        this.proveedorId = proveedorId; 
    }
    
 
    public Producto(String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, Categoria categoria, Proveedor proveedor) {
        this();
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.fechaFabricacion = fechaFabricacion;
        this.fechaCaducidad = fechaCaducidad;
        this.categoria = categoria;
        this.proveedor = proveedor; 
        
        if (categoria != null) {
            this.categoriaId = categoria.getId();
        }
        if (proveedor != null) {
            this.proveedorId = proveedor.getId(); 
        }
    }
    
 
    public Producto(int id, String nombre, int cantidad, double precio, Date fechaFabricacion, Date fechaCaducidad, Categoria categoria, Proveedor proveedor) {
      
        this(nombre, cantidad, precio, fechaFabricacion, fechaCaducidad, categoria, proveedor);
      
        this.id = id;
    }


   

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public Date getFechaFabricacion() {
        return fechaFabricacion;
    }

    public void setFechaFabricacion(Date fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
    }

    public Date getFechaCaducidad() {
        return fechaCaducidad;
    }

    public void setFechaCaducidad(Date fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }

    public List<Almacen> getAlmacenes() {
        return almacenes;
    }

    public void setAlmacenes(List<Almacen> almacenes) {
        this.almacenes = almacenes;
    }

    public int getCategoriaId() {
        return categoriaId;
    }

    public void setCategoriaId(int categoriaId) {
        this.categoriaId = categoriaId;
    }

    public int getProveedorId() {
        return proveedorId;
    }

    public void setProveedorId(int proveedorId) {
        this.proveedorId = proveedorId;
    }
    
    
    @Override
    public String toString() {
        return "Producto{"
                + "id=" + id
                + ", nombre='" + nombre + '\''
                + ", stock=" + cantidad
                + ", precio=" + precio
                + ", fabricacion=" + fechaFabricacion
                + ", caducidad=" + fechaCaducidad
                + ", categoria=" + (categoria != null ? categoria.getNombre() : "N/A")
                + ", proveedor=" + (proveedor != null ? proveedor.getNombre() : "N/A") 
                + ", num_registros_inventario=" + almacenes.size() 
                + '}';
    }
}