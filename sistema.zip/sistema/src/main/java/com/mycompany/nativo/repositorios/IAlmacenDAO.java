package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Almacen;
import java.sql.Connection;
import java.util.List;

public interface IAlmacenDAO {
    void crear(Almacen almacen) throws Exception;
    
 
    void crearConConexion(Connection conn, Almacen almacen) throws Exception;
    
    Almacen obtenerPorId(int id) throws Exception;
    List<Almacen> obtenerTodos() throws Exception;
    void actualizar(Almacen almacen) throws Exception;
    void eliminar(int id) throws Exception;
    List<Almacen> obtenerAlmacenesPorProductoId(int productoId) throws Exception;
}