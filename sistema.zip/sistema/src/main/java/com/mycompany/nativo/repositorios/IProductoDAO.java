package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Producto;
import java.sql.Connection; 
import java.util.List;

public interface IProductoDAO {
    void crear(Producto producto) throws Exception;
    Producto obtenerPorId(int id) throws Exception;
    List<Producto> obtenerTodos() throws Exception;
    void actualizar(Producto producto) throws Exception;
    void eliminar(int id) throws Exception;
    
  
    void actualizarStock(Connection conn, int productoId, int cantidadCambio) throws Exception;
    
  
    void agregarAlmacenAProducto(int productoId, int almacenId) throws Exception;
    void eliminarAlmacenDeProducto(int productoId, int almacenId) throws Exception;
}