package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import java.sql.*;

public class RecuperacionDAOJDBC implements IRecuperacionDAO {

    @Override
    public void guardarToken(int usuarioId, String token) throws Exception {
        // Expira en 15 minutos
        String sql = "INSERT INTO recuperacion_tokens (usuario_id, token, expiracion) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 15 MINUTE))";
        try (Connection conn = Config.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, usuarioId);
            stmt.setString(2, token);
            stmt.executeUpdate();
        }
    }

    @Override
    public int validarToken(String token) throws Exception {
        String sql = "SELECT usuario_id FROM recuperacion_tokens WHERE token = ? AND expiracion > NOW()";
        try (Connection conn = Config.getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, token);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) return rs.getInt("usuario_id");
            }
        }
        return 0; // No encontrado o expirado
    }

    @Override
    public void eliminarToken(String token) throws Exception {
        try (Connection conn = Config.getConnection(); PreparedStatement stmt = conn.prepareStatement("DELETE FROM recuperacion_tokens WHERE token = ?")) {
            stmt.setString(1, token);
            stmt.executeUpdate();
        }
    }
}