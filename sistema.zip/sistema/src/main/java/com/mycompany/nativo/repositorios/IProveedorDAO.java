/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Proveedor;
import java.util.List;

public interface IProveedorDAO {
    void crear(Proveedor proveedor) throws Exception;
    Proveedor obtenerPorId(int id) throws Exception;
    List<Proveedor> obtenerTodos() throws Exception;
    void actualizar(Proveedor proveedor) throws Exception;
    void eliminar(int id) throws Exception;
}