package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.Proveedor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAOJDBC implements IProveedorDAO {

    private static final String SQL_INSERT = "INSERT INTO Proveedor (nombre, ruc, telefono, direccion) VALUES (?, ?, ?, ?)";
    private static final String SQL_SELECT_BY_ID = "SELECT * FROM Proveedor WHERE id = ?";
    private static final String SQL_SELECT_ALL = "SELECT * FROM Proveedor";
    private static final String SQL_UPDATE = "UPDATE Proveedor SET nombre = ?, ruc = ?, telefono = ?, direccion = ? WHERE id = ?";
    private static final String SQL_DELETE = "DELETE FROM Proveedor WHERE id = ?";

    private Proveedor mapResultSetToProveedor(ResultSet rs) throws SQLException {
        return new Proveedor(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("ruc"),
                rs.getString("telefono"),
                rs.getString("direccion")
        );
    }

    @Override
    public void crear(Proveedor proveedor) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setString(1, proveedor.getNombre());
            stmt.setString(2, proveedor.getRuc());
            stmt.setString(3, proveedor.getTelefono());
            stmt.setString(4, proveedor.getDireccion());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    proveedor.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public Proveedor obtenerPorId(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToProveedor(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Proveedor> obtenerTodos() throws Exception {
        List<Proveedor> proveedores = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            while (rs.next()) {
                proveedores.add(mapResultSetToProveedor(rs));
            }
        }
        return proveedores;
    }

    @Override
    public void actualizar(Proveedor proveedor) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            stmt.setString(1, proveedor.getNombre());
            stmt.setString(2, proveedor.getRuc());
            stmt.setString(3, proveedor.getTelefono());
            stmt.setString(4, proveedor.getDireccion());
            stmt.setInt(5, proveedor.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    // --- IMPLEMENTACIÓN RF16 ---
    @Override
    public List<Proveedor> buscarPorNombre(String nombre) throws Exception {
        List<Proveedor> proveedores = new ArrayList<>();
        String sql = "SELECT * FROM Proveedor WHERE nombre LIKE ?";
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, "%" + nombre + "%");
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    proveedores.add(mapResultSetToProveedor(rs));
                }
            }
        }
        return proveedores;
    }
}