package com.mycompany.nativo.servicios;

import com.mycompany.nativo.modelos.Almacen;
import java.util.List;

public interface IAlmacenService {
    
  
    void registrarEntrada(Almacen registro) throws Exception;
    
 
    Almacen buscarRegistro(int id) throws Exception;
    
   
    List<Almacen> obtenerHistorial() throws Exception;
    
  
    void actualizarRegistro(Almacen registro) throws Exception;
  
    void eliminarRegistro(int id) throws Exception;
}