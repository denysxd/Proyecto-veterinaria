package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.HistorialLogin;
import java.util.List;

public interface IHistorialLoginDAO {
    void registrarLogin(int usuarioId, String ipAddress) throws Exception;
    List<HistorialLogin> obtenerTodos() throws Exception;
}