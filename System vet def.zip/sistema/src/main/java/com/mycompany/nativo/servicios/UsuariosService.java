package com.mycompany.nativo.servicios;

import com.mycompany.nativo.repositorios.*; 
import com.mycompany.nativo.modelos.*;
import java.sql.SQLException;
import java.util.List;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.math.BigInteger;
import java.net.InetAddress;
import java.util.UUID; 

public class UsuariosService {
    
    private final UsuariosDao usuarioDao;
    private final IHistorialLoginDAO historialDao;
    private final IRecuperacionDAO recuperacionDao; 
    private final CorreoService correoService; 

    public UsuariosService() {
        this.usuarioDao = new UsuariosDaoJDBC(); 
        this.historialDao = new HistorialLoginDAOJDBC();
        this.recuperacionDao = new RecuperacionDAOJDBC();
        this.correoService = new CorreoService();
    }

    private String hashearPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] encodedhash = digest.digest(password.getBytes(StandardCharsets.UTF_8));
            return String.format("%064x", new BigInteger(1, encodedhash));
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    public Usuarios login(String email, String contrasenaPlana) {
        Usuarios usuario = null;
        try {
            usuario = usuarioDao.obtenerUsuarioPorEmail(email); 
            
            if (usuario == null || !usuario.isActivo()) return null; 
            
            if (hashearPassword(contrasenaPlana).equals(usuario.getContrasena())) {
                try { historialDao.registrarLogin(usuario.getId(), InetAddress.getLocalHost().getHostAddress()); } catch(Exception e) { System.err.println("Error auditoria."); }
                return usuario; 
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }
    
    // --- RF30: INICIAR RECUPERACIÓN ---
    public boolean iniciarRecuperacion(String email) {
        try {
            Usuarios u = usuarioDao.obtenerUsuarioPorEmail(email);
            if (u == null) {
                System.out.println("❌ Ese correo no está registrado.");
                return false;
            }
            
            String token = UUID.randomUUID().toString().substring(0, 6).toUpperCase();
            recuperacionDao.guardarToken(u.getId(), token);
            boolean enviado = correoService.enviarCorreoRecuperacion(email, token);
            if(enviado) {
                System.out.println("✅ Se envió un código a " + email);
                return true;
            } else {
                return false;
            }
            
        } catch(Exception e) { 
            e.printStackTrace();
            return false; 
        }
    }
    
    // --- RF30: CAMBIAR CLAVE CON TOKEN (CORREGIDO) ---
    public boolean cambiarClaveConToken(String token, String nuevaPass) {
        try {
            int userId = recuperacionDao.validarToken(token);
            if (userId == 0) {
                System.out.println("❌ Token inválido o expirado.");
                return false;
            }
            
            Usuarios u = usuarioDao.obtenerUsuarioPorId(userId);
            u.setContrasena(hashearPassword(nuevaPass)); // 1. Hasheamos la nueva clave
            
            // 2. Usamos el método DEDICADO para actualizar la contraseña en BD
            usuarioDao.actualizarContrasena(u); 
            
            recuperacionDao.eliminarToken(token); 
            return true;
            
        } catch(Exception e) { e.printStackTrace(); return false; }
    }
    // ----------------------------------------

    public List<HistorialLogin> obtenerReporteAuditoria() throws Exception { return historialDao.obtenerTodos(); }
    
    public boolean crearUsuario(String u, String e, String p, int r) {
        try {
            if(usuarioDao.obtenerUsuarioPorEmail(e)!=null) return false;
            if(usuarioDao.obtenerUsuarioPorNombre(u)!=null) return false;
            return usuarioDao.insertar(new Usuarios(u,e,hashearPassword(p),r)) == 1;
        } catch(Exception ex) { return false; }
    }
    
    public List<Usuarios> listarUsuarios() throws Exception { return usuarioDao.obtenerTodos(); }
    public void eliminarUsuario(int id, int adminId) throws Exception { usuarioDao.eliminar(id); }
}