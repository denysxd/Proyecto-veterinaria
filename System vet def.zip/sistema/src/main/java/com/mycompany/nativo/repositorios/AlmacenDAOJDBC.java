package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.Config;
import com.mycompany.nativo.modelos.Almacen;
import com.mycompany.nativo.modelos.Producto; 
import com.mycompany.nativo.modelos.Usuarios;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlmacenDAOJDBC implements IAlmacenDAO {

    // Se asume que las columnas motivo y usuario_id están en las sentencias SQL
    private static final String SQL_INSERT = 
        "INSERT INTO almacen (producto_id, cantidad_movimiento, usuario_id, motivo) VALUES (?, ?, ?, ?)";
    private static final String SQL_SELECT_BY_ID = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id, motivo FROM almacen WHERE id = ?";
    private static final String SQL_SELECT_ALL = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id, motivo FROM almacen";
    private static final String SQL_UPDATE = 
        "UPDATE almacen SET producto_id = ?, cantidad_movimiento = ?, usuario_id = ?, motivo = ? WHERE id = ? ";
    private static final String SQL_DELETE = 
        "DELETE FROM almacen WHERE id = ?";
    private static final String SQL_SELECT_BY_PRODUCTO = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id, motivo FROM almacen WHERE producto_id = ?";
    
    // --- NUEVO (RF24) ---
    private static final String SQL_SELECT_BY_USER = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id, motivo FROM almacen WHERE usuario_id = ?";
    private static final String SQL_SELECT_BY_DATE_RANGE = 
        "SELECT id, producto_id, cantidad_movimiento, fecha_entrada, usuario_id, motivo FROM almacen WHERE fecha_entrada BETWEEN ? AND ?";


    private Almacen mapResultSetToAlmacen(ResultSet rs) throws SQLException {
        Producto productoPlaceholder = new Producto();
        productoPlaceholder.setId(rs.getInt("producto_id"));
        Usuarios usuarioPlaceholder = new Usuarios();
        usuarioPlaceholder.setId(rs.getInt("usuario_id"));
        
        return new Almacen(
            rs.getInt("id"),
            productoPlaceholder,
            rs.getInt("cantidad_movimiento"),
            rs.getDate("fecha_entrada"),
            usuarioPlaceholder,
            rs.getString("motivo")
        );
    }

    @Override
    public void crear(Almacen almacen) throws Exception {
        try (Connection conn = Config.getConnection()) {
            conn.setAutoCommit(true); 
            crearConConexion(conn, almacen);
        }
    }

    @Override
    public void crearConConexion(Connection conn, Almacen almacen) throws Exception {
        try (PreparedStatement stmt = conn.prepareStatement(SQL_INSERT, Statement.RETURN_GENERATED_KEYS)) {
            stmt.setInt(1, almacen.getProducto().getId());
            stmt.setInt(2, almacen.getCantidadEnAlmacen()); 
            stmt.setInt(3, almacen.getUsuario().getId());
            stmt.setString(4, almacen.getMotivo());
            stmt.executeUpdate();
            try (ResultSet rs = stmt.getGeneratedKeys()) {
                if (rs.next()) {
                    almacen.setId(rs.getInt(1));
                }
            }
        }
    }

    @Override
    public Almacen obtenerPorId(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToAlmacen(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Almacen> obtenerTodos() throws Exception {
        List<Almacen> almacenes = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            while (rs.next()) {
                almacenes.add(mapResultSetToAlmacen(rs));
            }
        }
        return almacenes;
    }

    @Override
    public void actualizar(Almacen almacen) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            stmt.setInt(1, almacen.getProducto().getId());
            stmt.setInt(2, almacen.getCantidadEnAlmacen()); 
            stmt.setInt(3, almacen.getUsuario().getId());
            stmt.setString(4, almacen.getMotivo());
            stmt.setInt(5, almacen.getId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws Exception {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
    
    @Override
    public List<Almacen> obtenerAlmacenesPorProductoId(int productoId) throws Exception {
        List<Almacen> almacenes = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_PRODUCTO)) {
            stmt.setInt(1, productoId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    almacenes.add(mapResultSetToAlmacen(rs));
                }
            }
        }
        return almacenes;
    }

    // --- IMPLEMENTACIÓN RF24 ---
    @Override
    public List<Almacen> obtenerPorUsuario(int usuarioId) throws Exception {
        List<Almacen> almacenes = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_USER)) {
            
            stmt.setInt(1, usuarioId);
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    almacenes.add(mapResultSetToAlmacen(rs));
                }
            }
        }
        return almacenes;
    }
    
    @Override
    public List<Almacen> obtenerPorRangoFechas(String fechaInicio, String fechaFin) throws Exception {
        List<Almacen> almacenes = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_DATE_RANGE)) {
            
            stmt.setDate(1, Date.valueOf(fechaInicio));
            stmt.setDate(2, Date.valueOf(fechaFin)); 
            
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    almacenes.add(mapResultSetToAlmacen(rs));
                }
            }
        } catch (IllegalArgumentException e) {
            throw new Exception("Formato de fecha inválido. Use YYYY-MM-DD.", e);
        }
        return almacenes;
    }
}