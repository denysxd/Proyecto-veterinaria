package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Usuarios;
import java.sql.SQLException;
import java.util.List;

public interface UsuariosDao {

    Usuarios obtenerUsuarioPorNombre(String nombreUsuario) throws SQLException;
    Usuarios obtenerUsuarioPorEmail(String email) throws SQLException;
    int insertar(Usuarios usuario) throws SQLException; 
    List<Usuarios> obtenerTodos() throws SQLException;
    Usuarios obtenerUsuarioPorId(int id) throws SQLException;
    void actualizar(Usuarios usuario) throws SQLException;
    void eliminar(int id) throws SQLException;
    
    // --- NUEVO MÉTODO PARA LA RECUPERACIÓN (RF30) ---
    void actualizarContrasena(Usuarios usuario) throws SQLException;
}