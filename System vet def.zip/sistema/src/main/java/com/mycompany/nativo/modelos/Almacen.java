package com.mycompany.nativo.modelos; 

import java.sql.Date; 

public class Almacen {
    
    private int id; 
    private Producto producto; 
    private int cantidadEnAlmacen;
    private Date fechaEntrada;
    private Usuarios usuario;
    private String motivo; // <--- CAMPO OBLIGATORIO PARA RF9
    

    // Constructor 1: Para CREAR (Usado en Main.java - registrarVenta)
    public Almacen(Producto producto, int cantidadEnAlmacen, Usuarios usuario, String motivo) {
        this.producto = producto;
        this.cantidadEnAlmacen = cantidadEnAlmacen;
        this.usuario = usuario;
        this.motivo = motivo;
    }
    
    // Constructor 2: Para LEER (Usado en AlmacenDAOJDBC)
    public Almacen(int id, Producto producto, int cantidadEnAlmacen, Date fechaEntrada, Usuarios usuario, String motivo) {
        this.id = id;
        this.producto = producto;
        this.cantidadEnAlmacen = cantidadEnAlmacen;
        this.fechaEntrada = fechaEntrada;
        this.usuario = usuario;
        this.motivo = motivo;
    }

    // Constructor 3: Vacío
    public Almacen() {}


    // --- Getters y Setters ---

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public Producto getProducto() { return producto; }
    public void setProducto(Producto producto) { this.producto = producto; }

    public int getCantidadEnAlmacen() { return cantidadEnAlmacen; }
    public void setCantidadEnAlmacen(int cantidadEnAlmacen) { this.cantidadEnAlmacen = cantidadEnAlmacen; }

    public Date getFechaEntrada() { return fechaEntrada; }
    public void setFechaEntrada(Date fechaEntrada) { this.fechaEntrada = fechaEntrada; }

    public Usuarios getUsuario() { return usuario; }
    public void setUsuario(Usuarios usuario) { this.usuario = usuario; }
    
    // --- ESTE ES EL QUE TE ESTÁ DANDO ERROR ---
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    // -----------------------------------------

    @Override
    public String toString() {
        return "RegistroAlmacen{" + "id=" + id + ", motivo=" + motivo + '}';
    }
}