package com.mycompany.nativo.modelos;

import java.sql.Timestamp;

public class Usuarios {

    private int id;
    private String nombreUsuario;
    private String email; 
    private String contrasena; 
    private int rolId;
    private boolean activo; 
    private Timestamp fechaCreacion; 


    public Usuarios(String nombreUsuario, String email, String contrasena, int rolId) {
        this.nombreUsuario = nombreUsuario;
        this.email = email; // 🔄
        this.contrasena = contrasena;
        this.rolId = rolId;
        this.activo = true;
    }
    
   
    public Usuarios(int id, String nombreUsuario, String email, String contrasena, int rolId, boolean activo, Timestamp fechaCreacion) {
        this.id = id;
        this.nombreUsuario = nombreUsuario;
        this.email = email; // 🔄
        this.contrasena = contrasena;
        this.rolId = rolId;
        this.activo = activo;
        this.fechaCreacion = fechaCreacion;
    }

   
    public Usuarios() {
    }


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
 
    @Override
    public String toString() {
        return "Usuarios{" +
                "id=" + id +
                ", nombreUsuario='" + nombreUsuario + '\'' +
                ", email='" + email + '\'' + // 🔄
                ", rolId=" + rolId +
                ", activo=" + activo +
                '}';
    }
    
   
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombreUsuario() { return nombreUsuario; }
    public void setNombreUsuario(String nombreUsuario) { this.nombreUsuario = nombreUsuario; }
    public String getContrasena() { return contrasena; }
    public void setContrasena(String contrasena) { this.contrasena = contrasena; }
    public int getRolId() { return rolId; }
    public void setRolId(int rolId) { this.rolId = rolId; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
    public Timestamp getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(Timestamp fechaCreacion) { this.fechaCreacion = fechaCreacion; }
}