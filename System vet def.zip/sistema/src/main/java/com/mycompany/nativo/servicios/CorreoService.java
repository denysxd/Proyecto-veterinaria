package com.mycompany.nativo.servicios;

import java.util.Properties;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class CorreoService {

    // --- CONFIGURACIÓN DE TU CORREO ---
    // ¡CAMBIA ESTO POR TUS DATOS REALES!
    private final String remite = "veterinariagus@gmail.com"; 
    private final String clave = "olxv rcmr ddxl gayc"; // Las 16 letras de Google
    
    public boolean enviarCorreoRecuperacion(String destinatario, String token) {
        System.out.println("📨 Enviando correo a: " + destinatario + "...");
        
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remite, clave);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(remite));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destinatario));
            message.setSubject("Recuperación de Contraseña - Veterinaria");
            message.setText("Hola,\n\n"
                    + "Has solicitado restablecer tu contraseña.\n"
                    + "Tu CÓDIGO DE RECUPERACIÓN es: " + token + "\n\n"
                    + "Copia este código en el sistema para crear una nueva clave.\n"
                    + "Este código expira en 15 minutos.");

            Transport.send(message);
            System.out.println("✅ Correo enviado con éxito.");
            return true;

        } catch (MessagingException e) {
            System.err.println("❌ Error enviando correo: " + e.getMessage());
            // e.printStackTrace(); // Descomenta si quieres ver el error técnico completo
            return false;
        }
    }
}