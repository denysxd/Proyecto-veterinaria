package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Proveedor;
import java.util.List;

public interface IProveedorDAO {
    void crear(Proveedor proveedor) throws Exception;
    Proveedor obtenerPorId(int id) throws Exception;
    List<Proveedor> obtenerTodos() throws Exception;
    void actualizar(Proveedor proveedor) throws Exception;
    void eliminar(int id) throws Exception;
    
    // --- MÉTODO FALTANTE ---
    List<Proveedor> buscarPorNombre(String nombre) throws Exception;
}