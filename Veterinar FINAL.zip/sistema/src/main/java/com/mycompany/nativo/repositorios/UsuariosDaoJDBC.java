package com.mycompany.nativo.repositorios;

import com.mycompany.nativo.modelos.Usuarios;
import com.mycompany.nativo.Config;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

public class UsuariosDaoJDBC implements UsuariosDao {

    private static final String SQL_SELECT_BY_USERNAME = 
        "SELECT id, nombre_usuario, email, contraseña, rol_id, activo, fecha_creacion " + 
        "FROM usuarios WHERE nombre_usuario = ?";
        
    private static final String SQL_SELECT_BY_EMAIL = 
        "SELECT id, nombre_usuario, email, contraseña, rol_id, activo, fecha_creacion " + 
        "FROM usuarios WHERE email = ?";
        
    private static final String SQL_INSERT = 
        "INSERT INTO usuarios (nombre_usuario, email, contraseña, rol_id) VALUES (?, ?, ?, ?)";

    private static final String SQL_SELECT_ALL = 
        "SELECT id, nombre_usuario, email, contraseña, rol_id, activo, fecha_creacion FROM usuarios";
        
    private static final String SQL_SELECT_BY_ID = 
        "SELECT id, nombre_usuario, email, contraseña, rol_id, activo, fecha_creacion FROM usuarios WHERE id = ?";

    private static final String SQL_UPDATE = 
        "UPDATE usuarios SET nombre_usuario = ?, email = ?, rol_id = ?, activo = ? WHERE id = ?";
        
    private static final String SQL_DELETE = 
        "DELETE FROM usuarios WHERE id = ?";
        
    private Usuarios mapResultSetToUsuario(ResultSet rs) throws SQLException {
        int id = rs.getInt("id");
        String nombreUsuario = rs.getString("nombre_usuario");
        String email = rs.getString("email"); 
        String contrasena = rs.getString("contraseña");
        int rolId = rs.getInt("rol_id");
        boolean activo = rs.getBoolean("activo"); 
        Timestamp fechaCreacion = rs.getTimestamp("fecha_creacion"); 
        
        return new Usuarios(id, nombreUsuario, email, contrasena, rolId, activo, fechaCreacion);
    }

    @Override
    public Usuarios obtenerUsuarioPorNombre(String nombreUsuario) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_USERNAME)) {
            stmt.setString(1, nombreUsuario);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    usuario = mapResultSetToUsuario(rs);
                }
            }
        }
        return usuario;
    }

    @Override
    public Usuarios obtenerUsuarioPorEmail(String email) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_EMAIL)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    usuario = mapResultSetToUsuario(rs);
                }
            }
        }
        return usuario;
    }

   @Override
    public int insertar(Usuarios usuario) throws SQLException {
        int registrosAfectados = 0;
        
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_INSERT)) {
            
            stmt.setString(1, usuario.getNombreUsuario());
            stmt.setString(2, usuario.getEmail()); 
            stmt.setString(3, usuario.getContrasena()); 
            stmt.setInt(4, usuario.getRolId());

            // CORREGIDO: Usamos la variable externa
            registrosAfectados = stmt.executeUpdate(); 
        }
        return registrosAfectados;
    }

    @Override
    public List<Usuarios> obtenerTodos() throws SQLException {
        List<Usuarios> usuarios = new ArrayList<>();
        try (Connection conn = Config.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL)) {
            
            while (rs.next()) {
                usuarios.add(mapResultSetToUsuario(rs));
            }
        }
        return usuarios;
    }

    @Override
    public Usuarios obtenerUsuarioPorId(int id) throws SQLException {
        Usuarios usuario = null;
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_SELECT_BY_ID)) {
            
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    usuario = mapResultSetToUsuario(rs);
                }
            }
        }
        return usuario;
    }

    @Override
    public void actualizar(Usuarios usuario) throws SQLException {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_UPDATE)) {
            
            stmt.setString(1, usuario.getNombreUsuario());
            stmt.setString(2, usuario.getEmail()); 
            stmt.setInt(3, usuario.getRolId());
            stmt.setBoolean(4, usuario.isActivo());
            stmt.setInt(5, usuario.getId());
            
            stmt.executeUpdate();
        }
    }

    @Override
    public void eliminar(int id) throws SQLException {
        try (Connection conn = Config.getConnection();
             PreparedStatement stmt = conn.prepareStatement(SQL_DELETE)) {
            
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }
}